-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2015 at 02:03 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cmsc128`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_username` varchar(30) NOT NULL,
  `account_password` varchar(30) NOT NULL,
  `emp_num` int(11) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_username` (`account_username`),
  KEY `emp_num` (`emp_num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `account_username`, `account_password`, `emp_num`) VALUES
(1, 'mary', '123', 201220694),
(2, '201412345', '2520141234515', 201412345),
(3, '2012206946', '12201220694622', 2012206946),
(4, '2016', '2820169', 2016),
(5, '201212347', '2820121234721', 201212347),
(6, '20123232', '13201232327', 20123232);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `grading_period` varchar(10) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `student_days_tardy` int(11) NOT NULL,
  `student_days_present` int(11) NOT NULL,
  `school_days` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  KEY `batch_id` (`batch_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`grading_period`, `batch_id`, `student_days_tardy`, `student_days_present`, `school_days`, `student_id`) VALUES
('Fourth', 1, 24, 23, 25, 200317354);

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE IF NOT EXISTS `batch` (
  `batch_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_year` varchar(20) NOT NULL,
  `section` varchar(20) NOT NULL,
  `adviser` varchar(50) NOT NULL,
  `start_of_academic_year` year(4) NOT NULL,
  `end_of_academic_year` year(4) NOT NULL,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`batch_id`, `student_year`, `section`, `adviser`, `start_of_academic_year`, `end_of_academic_year`) VALUES
(1, 'IV', 'Hello', 'Reginald', 0000, 0000),
(2, 'III', 'Acacia', 'Joman Encinas', 2012, 2013),
(3, 'IV', 'Hello', 'Reginald', 2024, 2026);

-- --------------------------------------------------------

--
-- Table structure for table `batch_student_reference`
--

CREATE TABLE IF NOT EXISTS `batch_student_reference` (
  `batch_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `total_school_days` int(11) NOT NULL,
  `total_days_present` int(11) NOT NULL,
  `total_days_tardy` int(11) NOT NULL,
  KEY `batch_id` (`batch_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch_student_reference`
--

INSERT INTO `batch_student_reference` (`batch_id`, `student_id`, `total_school_days`, `total_days_present`, `total_days_tardy`) VALUES
(2, 200317354, 0, 0, 0),
(2, 199514352, 0, 0, 0),
(2, 200317354, 0, 0, 0),
(2, 200317355, 0, 0, 0),
(2, 200317356, 0, 0, 0),
(1, 200317356, 0, 0, 0),
(1, 200317356, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `edit_history`
--

CREATE TABLE IF NOT EXISTS `edit_history` (
  `edit_history_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `emp_num` varchar(11) NOT NULL,
  `page` varchar(50) NOT NULL,
  `remarks` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `edit_history`
--

INSERT INTO `edit_history` (`edit_history_id`, `date`, `emp_num`, `page`, `remarks`) VALUES
(0, '2015-04-24 07:06:24', '201220694', 'edit attendance', '200317354 1 Fourth 23 23 23'),
(0, '2015-04-24 07:33:46', '201220694', 'edit attendance', '200317354   1   Fourth   23   23   23'),
(0, '2015-04-24 07:34:30', '201220694', 'edit attendance', '200317354   1   Fourth   23   23   0'),
(0, '2015-04-24 07:36:04', '201220694', 'edit attendance', '200317354   1   Fourth   21   0   21'),
(0, '2015-04-24 09:24:38', '201220694', 'edit attendance', 'Fourth   1   0      78   78200317354'),
(0, '2015-04-24 09:37:26', '201220694', 'edit attendance', 'Marion Dagang   adviser   '),
(0, '2015-04-24 10:15:07', '201220694', 'edit attendance', 'IV   Acacia   Joman Encinas      2012   2013'),
(0, '2015-04-24 10:19:06', '201220694', 'edit attendance', 'III   Acacia   Joman Encinas      2012   2013');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `Emp_num` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `Admin_flag` tinyint(1) DEFAULT NULL,
  `Subj_teacher_flag` tinyint(1) DEFAULT NULL,
  `Adviser_flag` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`Emp_num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Emp_num`, `name`, `designation`, `Admin_flag`, `Subj_teacher_flag`, `Adviser_flag`) VALUES
(0, 'Mary Kristene D. Clarino', 'adviser', 0, 0, 1),
(2016, 'Marion P. Dagang', 'admin', 1, 0, 0),
(20123232, 'Mary Kristene D. Clarino', 'adviser', 0, 0, 1),
(201212345, 'Harry', 'admin', 1, 0, 0),
(201212347, 'Ashton Irwin', 'admin', 1, 0, 0),
(201220694, 'Mary Kristene D. Clarino', 'adviser', 0, 0, 1),
(201412345, 'Paolo Javelona', 'adviser', 0, 0, 1),
(2012206946, 'Mary Kristene D. Clarino', 'adviser', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `logs_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `emp_num` varchar(11) NOT NULL,
  `activity` varchar(30) NOT NULL,
  `remarks` varchar(300) NOT NULL,
  PRIMARY KEY (`logs_id`),
  KEY `emp_num` (`emp_num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`logs_id`, `date`, `emp_num`, `activity`, `remarks`) VALUES
(1, '2015-04-24 06:50:32', '201220694', 'LOG-IN', ''),
(2, '2015-04-24 07:06:24', '201220694', 'Edited Attendance', 'Edited 200317354: Fourthwith batch 1'),
(3, '2015-04-24 07:29:39', '201220694', 'LOG-IN', ''),
(4, '2015-04-24 07:33:46', '201220694', 'Edited Attendance', 'Edited 200317354: Fourthwith batch 1'),
(5, '2015-04-24 07:34:30', '201220694', 'Edited Attendance', 'Edited 200317354: Fourthwith batch 1'),
(6, '2015-04-24 07:36:05', '201220694', 'Edited Attendance', 'Edited 200317354: Fourthwith batch 1'),
(7, '2015-04-24 09:24:38', '201220694', 'Edited Attendance', 'Edited 200317354: Fourthwith batch 1'),
(8, '2015-04-24 09:37:26', '201220694', 'Edited Employee', 'Edited 2016'),
(9, '2015-04-24 10:15:07', '201220694', 'Edited Batch', 'Edited III-Acacia:  Joman Encinas'),
(10, '2015-04-24 10:19:06', '201220694', 'Edited Batch', 'Edited III-Acacia:  Joman Encinas'),
(11, '2015-04-24 10:46:50', '201220694', 'LOG-IN', ''),
(12, '2015-04-24 11:06:05', '201220694', 'LOG-IN', ''),
(13, '2015-04-24 11:10:29', '201220694', 'LOG-IN', ''),
(14, '2015-04-24 11:24:43', '201220694', 'LOG-IN', ''),
(15, '2015-04-24 11:42:22', '201220694', 'LOG-IN', ''),
(16, '2015-04-24 11:42:39', '201220694', 'LOG-IN', ''),
(17, '2015-04-24 11:44:47', '201220694', 'LOG-IN', ''),
(18, '2015-04-24 11:59:14', '201220694', 'LOG-IN', ''),
(19, '2015-04-24 12:29:16', '201220694', 'LOG-IN', ''),
(20, '2015-04-24 12:48:19', '201220694', 'LOG-IN', ''),
(21, '2015-04-24 12:50:07', '201220694', 'LOG-IN', ''),
(22, '2015-04-24 12:50:42', '201220694', 'LOG-IN', ''),
(23, '2015-04-24 12:51:02', '201220694', 'LOG-IN', ''),
(24, '2015-04-24 12:52:11', '201220694', 'LOG-IN', ''),
(25, '2015-04-24 13:13:38', '201220694', 'LOG-IN', ''),
(26, '2015-04-24 13:14:06', '201220694', 'LOG-IN', ''),
(27, '2015-04-24 13:14:19', '201220694', 'Added Student to Batch', 'Added 200317356to 1'),
(28, '2015-04-24 13:15:35', '201220694', 'LOG-IN', ''),
(29, '2015-04-24 13:15:50', '201220694', 'Added Student to Batch', 'Added 200317356to 1'),
(30, '2015-04-24 13:17:25', '201220694', 'LOG-IN', ''),
(31, '2015-04-24 13:17:44', '201220694', 'LOG-IN', ''),
(32, '2015-04-24 13:18:34', '201220694', 'LOG-IN', ''),
(33, '2015-04-24 13:21:19', '201220694', 'LOG-IN', ''),
(34, '2015-04-24 13:37:29', '201220694', 'LOG-IN', ''),
(35, '2015-04-24 13:38:35', '201220694', 'LOG-IN', ''),
(36, '2015-04-24 13:38:59', '201220694', 'LOG-IN', ''),
(37, '2015-04-24 13:40:01', '201220694', 'LOG-IN', ''),
(38, '2015-04-24 13:40:06', '201220694', 'Added Subject To Student', '1'),
(39, '2015-04-24 13:58:09', '201220694', 'LOG-IN', ''),
(40, '2015-04-24 13:59:32', '201220694', 'LOG-IN', ''),
(41, '2015-04-24 13:59:57', '201220694', 'Added Subject To Student', '1'),
(42, '2015-04-24 14:00:08', '201220694', 'LOGGED-OUT', '');

-- --------------------------------------------------------

--
-- Table structure for table `report_card`
--

CREATE TABLE IF NOT EXISTS `report_card` (
  `Report_card_id` int(11) NOT NULL AUTO_INCREMENT,
  `Student_ave_grade` float NOT NULL,
  `Student_id` int(11) NOT NULL,
  `Emp_num` int(11) NOT NULL,
  PRIMARY KEY (`Report_card_id`),
  KEY `Student_id` (`Student_id`,`Emp_num`),
  KEY `Emp_num` (`Emp_num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `Student_id` int(11) NOT NULL AUTO_INCREMENT,
  `Student_name` varchar(50) NOT NULL,
  `Student_sex` varchar(6) NOT NULL,
  `status` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `nationality` varchar(20) NOT NULL,
  `curriculum` varchar(30) NOT NULL,
  `birthdate` date NOT NULL,
  PRIMARY KEY (`Student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=200317357 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Student_id`, `Student_name`, `Student_sex`, `status`, `address`, `nationality`, `curriculum`, `birthdate`) VALUES
(199514352, 'Hipolito Hipulpol', 'M', 'suspended', 'batong malake, los banos', 'Filipino', 'vocational', '1985-06-10'),
(200317354, 'Jupol Jupolito', 'M', 'still enrolled', 'batong maliit, los banos', 'Filipino', 'vocational', '0000-00-00'),
(200317355, 'Louise Marie Rose T. Alvaran', 'Female', 'Good', '2012-18669', 'Filipino', 'College', '1995-10-17'),
(200317356, 'Mary Clarino', 'Male', 'Machopapi', 'Hogwarts', 'British', 'Nursery', '1992-09-13');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject_reference`
--

CREATE TABLE IF NOT EXISTS `student_subject_reference` (
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `Final_grade` int(11) NOT NULL,
  `Subject_action` varchar(20) NOT NULL,
  KEY `student_id` (`student_id`,`subject_id`),
  KEY `subject_id` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `Subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `Subject_type` varchar(20) NOT NULL,
  `Subject_unit` int(11) NOT NULL,
  `Subject_name` varchar(20) NOT NULL,
  `Time_slot_start` time NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Emp_num` int(11) NOT NULL,
  `Time_slot_end` int(11) NOT NULL,
  PRIMARY KEY (`Subject_id`),
  KEY `Student_id` (`Emp_num`),
  KEY `Emp_num` (`Emp_num`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`Subject_id`, `Subject_type`, `Subject_unit`, `Subject_name`, `Time_slot_start`, `Description`, `Emp_num`, `Time_slot_end`) VALUES
(1, 'Regular', 3, 'CMSC128', '09:00:00', 'CMSC', 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `subject_grade`
--

CREATE TABLE IF NOT EXISTS `subject_grade` (
  `grading_period` varchar(20) NOT NULL,
  `grade` float NOT NULL,
  `Subject_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  KEY `Subject_id` (`Subject_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject_section`
--

CREATE TABLE IF NOT EXISTS `subject_section` (
  `Subject_id` int(11) NOT NULL,
  `section_name` varchar(20) NOT NULL,
  KEY `Subject_id` (`Subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `emp_num_fk` FOREIGN KEY (`emp_num`) REFERENCES `employee` (`Emp_num`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `batch_id_fk` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`batch_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_id_fk4` FOREIGN KEY (`student_id`) REFERENCES `student` (`Student_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `batch_student_reference`
--
ALTER TABLE `batch_student_reference`
  ADD CONSTRAINT `batch_to_student_fk` FOREIGN KEY (`batch_id`) REFERENCES `batch` (`batch_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_id_fk7` FOREIGN KEY (`student_id`) REFERENCES `student` (`Student_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `report_card`
--
ALTER TABLE `report_card`
  ADD CONSTRAINT `emp_num_fk2` FOREIGN KEY (`Emp_num`) REFERENCES `employee` (`Emp_num`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_id_fk2` FOREIGN KEY (`Student_id`) REFERENCES `student` (`Student_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_subject_reference`
--
ALTER TABLE `student_subject_reference`
  ADD CONSTRAINT `student_id_fk6` FOREIGN KEY (`student_id`) REFERENCES `student` (`Student_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_id_student_fk` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`Subject_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `emp_num_fk3` FOREIGN KEY (`Emp_num`) REFERENCES `employee` (`Emp_num`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subject_grade`
--
ALTER TABLE `subject_grade`
  ADD CONSTRAINT `student_id_fk3` FOREIGN KEY (`student_id`) REFERENCES `student` (`Student_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `subject_id_fk` FOREIGN KEY (`Subject_id`) REFERENCES `subject` (`Subject_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subject_section`
--
ALTER TABLE `subject_section`
  ADD CONSTRAINT `subject_id_fk2` FOREIGN KEY (`Subject_id`) REFERENCES `subject` (`Subject_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
