<!DOCTYPE html>
<!--
Copyright (c) 2015, the development team
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

Created on : Apr 10, 2015, 11:29:13 PM
Author     : John Paul Quijano
-->

<html>
    <head>
        <title></title>

       
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>

        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/main.css"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/subject_teacher.css"/>

        <script type="text/JavaScript" src="<?php echo base_url();?>frameworks/jquery-2.1.3.js"></script>
        <script type="text/JavaScript" src="<?php echo base_url();?>frameworks/jquery.color-2.1.2.js"></script>
        <script type="text/JavaScript" src="<?php echo base_url();?>frameworks/factory.js"></script>  </head>
    <body>
        <div id="background">
            <div id="centerblock">
                <div id="topblock">
                    <div id="header">
                        <div id="logopanel">
                        </div>

                        <div id="schoolname">
                            <span id="university">UNIVERSITY OF THE PHILIPPINES </span>
                            <span id="highschool">RURAL HIGH SCHOOL</span>
                        </div>
                    </div>

                    <div id="toolbar">
                        <div id="userpanel">Teacher</div>

                        <div id="signout" class="tool" tooltip="Sign-out" invoke="signoutdialog"></div>
                        <div id="about" class="tool" tooltip="About" invoke="aboutdialog"></div>
                        <div id="sendmessage" class="tool" tooltip="Send Message" invoke="messagedialog"></div>
                        <div id="search" class="tool" tooltip="Search"></div>
                        <div id="searchfield" class="singleline" contenteditable="true">Search</div>
                    </div>
                </div>

                <div id="floatingtoolbar">
                    <div id="floatingtoolwrapper">
                        <div id="floatingsearchfield" class="singleline" contenteditable="true">Search</div>
                        <div id="floatingsearch" class="floatingtool"></div>
                        <div id="floatingsendmessage" class="floatingtool" invoke="messagedialog"></div>
                        <div id="floatingabout" class="floatingtool" invoke="aboutdialog"></div>
                        <div id="floatingsignout" class="floatingtool" invoke="signoutdialog"></div>
                    </div>
                </div>

                <div id="signoutdialog" class="dialog">
                    <div class="titlebar">
                        <span>Sign-out</span>
                        <div id="signoutdialogclosebutton" class="dialogclosebutton" tooltip="Cancel"></div> 
                    </div>

                    <div id="signoutdialogcontent" class="dialogcontent">
                        Confirm Sign-out
                    </div>

                    <div class="buttonbar">
                        <div id="signoutdialogokbutton" class="dialogokbutton" tooltip="OK"></div>
                    </div>
                </div>

                <div id="aboutdialog" class="dialog">
                    <div class="titlebar">
                        <span>About</span>
                        <div id="aboutdialogclosebutton" class="dialogclosebutton" tooltip="Close"></div>
                    </div>
                </div>

                <div id="messagedialog" class="dialog">
                    <div class="titlebar">
                        <span>Send Message</span>
                        <div id="messagedialogclosebutton" class="dialogclosebutton" tooltip="Cancel"></div>
                    </div>

                    <div id="messagedialogcontent" class="dialogcontent">
                        <div class="label">To</div>
                        <div id="messagetotextfield" class="textfield singleline" contenteditable="true"></div><br/>

                        <div class="label">Message</div>
                        <div id="messagecontenttextarea" class="textarea" contenteditable="true"></div>
                    </div>

                    <div class="buttonbar">
                        <div id="messagedialogokbutton" class="dialogokbutton" tooltip="Send"></div>
                    </div>
                </div>

                <div id="contentpanel">
                    
                <div id="tabs">
                    <nav>
                        <a id="STmenu" href="#tabs-1">Student's List</a>
                        <a id="STmenu"  href="#tabs-2">Subject</a>
                        <a id="STmenu"  href="#tabs-3">Grade</a>
                        <a id="STmenu"  href="#tabs-4">Attendance</a>
                    </nav>
                    <div id="tabs-1">
                        <div id="subjectTeacherTree">
                            <h3>Subjects</h3>
                                <div id="subjects"></div>
                        </div>
                    </div>

                    <div id="tabs-2">
                        <?php
                            echo form_fieldset();
                            echo '<p id="PanelTitle">Add Subject</p>';
                            echo form_open('subject/..'); // Specify the right controller pleaseeeee! :))
                            echo '<ul>';
                            $studentName = array('type' => 'text', 'class' => 'text', 'placeholder' => 'Name of Student', 'name' => 'name', 'required' => 'true');
                            
                            echo '<li>'.form_input($studentName).'</li>';
                            $subjectName = array('type' => 'text', 'class' => 'text', 'placeholder' => 'Student', 'name' => 'name', 'required' => 'true');
                            echo '<li>'.form_input($subjectName).'<li>';
                            $submitSubject = array('class' => 'submit', "type" => 'submit');
                            echo '</ul>';
                            echo '<div class="submit">'.form_submit('submit', 'Add Subject').'</div>';
                            echo form_close();
                            echo form_fieldset_close();
                        ?>

                        <?php
                            echo form_fieldset();
                            echo '<p id="PanelTitle"> Delete Subject </p>';
                            echo form_open('subject/..'); // Specify the right controller please! :))
                            echo '<ul>';
                            $studentName = array('type' => 'text', 'class' => 'text', 'placeholder' => 'Name of Student', 'name' => 'name', 'required' => 'true');
                            echo '<li>'.form_input($studentName).'</li>';
                            $subjectName = array('type' => 'text', 'class' => 'text', 'placeholder' => 'Student', 'name' => 'name', 'required' => 'true');
                            echo '<li>'.form_input($subjectName).'</li>';
                            $submitSubject = array('class' => 'submit', "type" => 'submit');
                            echo '</ul>';
                            echo '<div class="submit">'.form_submit('submit', 'Delete Subject').'</div>';
                            echo form_close();
                            echo form_fieldset_close();
                        ?>
                    </div>

                    <div id="tabs-3">
                          <fieldset>
                             <center>ADD GRADE</center>
                        <form>
                            <ul>
                                <li>
                                    <input type="text" class="text" value="Name of Student" name="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Full Name';}" required>
                                </li>
                                <li>
                                    <input type="text" class="text" value="Subject" name="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Full Name';}" required>
                                </li>                            
                            </ul>
                        </form>
                            <div class="submit">
                               <input type="submit" onclick="myFunction()" value="ADD GRADE" >
                            </div>
                        </fieldset>
                      

                       <fieldset>
                             <center>Delete GRADE</center>
                        <form>
                            <ul>
                                <li>
                                    <input type="text" class="text" value="Name of Student" name="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Full Name';}" required>
                                </li>
                                <li>
                                    <input type="text" class="text" value="Subject" name="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Full Name';}" required>
                                </li>

                            </ul>
                        </form>
                            <div class="submit">
                                <input type="submit" onclick="myFunction()" value="DELETE GRADE" >
                            </div>
                        </fieldset>

                       <fieldset>
                             <center>EDIT GRADE</center>
                        <form>
                            <ul>
                                <li>
                                    <center><input type="text" class="text" value="Name of Student" name="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Full Name';}" required></center>
                                </li>
                                <li>
                                    <center><input type="text" class="text" value="Subject" name="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Full Name';}" required></center>
                                </li>
                                <li>
                                    <center><input type="text" class="text" value="Enter New Grade" name="name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Full Name';}" required></center>
                                </li>
                            </ul>
                        </form>
                            <div class="submit">
                                <center><input type="submit" onclick="myFunction()" value="EDIT GRADE" ></center>
                            </div>
                        </fieldset>

                    </div>
                    <div id="tabs-4">
                        ATTENDANCE
                        <fieldset>
                            ADD ATTENDANCE
                            <form>
                                <ul>
                                    <li>
                                        <input type="text" class="text" value="Student ID" >
                                    </li>

                                     <li>
                                        <input type="text" class="text" value="BatchID" >
                                    </li>
                                     <li>
                                        <input type="text" class="text" value="Grading Period" >
                                    </li>
                                    <li>
                                        <input type="text" class="text" value="Number of Days Present" >
                                    </li> 
                                    <li>
                                        <input type="text" class="text" value="Number of Days Tardy" >
                                    </li>
                                    <li>
                                        <input type="text" class="text" value="Total Number of Days" >
                                    </li>
                                </ul>

                            </form>
                            <div class="submit" value="ADD ATTENDANCE"></div>
                        </fieldset>
                        
                        <fieldset>
                            DELETE
                                <input type="text" class="text" value="Student ID" >

                        </fieldset>

                        <fieldset>
                            
                        EDIT ATTENDANCE
                            <form>
                                <ul>
                                    <li>
                                        <input type="text" class="text" value="Student ID">
                                    </li>
                                    <li>
                                        <input type="text" class="text" value="Grading Period" >
                                    </li>
                                    <li>
                                        <input type="text" class="text" value="Number of Days Present" >
                                    </li> 
                                    <li>
                                        <input type="text" class="text" value="Number of Days Tardy" >
                                    </li>
                                    <li>
                                        <input type="text" class="text" value="Total Number of Days" >
                                    </li>

                                </ul>

                            </form>
                            <div>
                                <input type="submit" value="EDIT ATTENDANCE">
                            </div>
                        </fieldset>

                           
                </div>

              <div id="notification"></div>
                <div id="loadinganimation"></div>

                <div id="copyright">Copyright © 2015, <a href="#" onclick="$('#aboutdialog').css('visibility', 'visible').fadeTo('fast', 0.9)">the development team</a>. All rights reserved.</div>
               </div>
            </div>
        </div>
    </div>

          <script type="text/JavaScript">
             var admins = [];
            var subjects = [];
            var teachers = [];
            var students = [];
            var advisers = [];
            var advisees = [];
            var numAdmins = 5;
            var numSubjects = 5;
            var numTeachers = 5;
            var numStudents = 5;
            var numAdvisers = 15;
            var numAdvisees = 5;

            for(var i = 0; i < numSubjects; i++) //initialize subject subtree elements
            {
                teachers[i] = []; 
                students[i] = [];

                for(var j = 0; j < numTeachers; j++)
                {
                    students[i][j] = [];
                    
                }
            }
             $(document).ready //this block executes after all the DOM elements have been loaded
            (
                function()
                {
                    initialize();
                   $( "#tabs" ).tabs();

                   
                    createAccordion("#subjectTeacherTree").accordion({active: 0}) //root of the entity tree
                    .position
                    (
                        {
                            my: "center",
                            at: "center",
                            of: "#content"
                        }
                    );

                    createAccordion("#subjects"); //root of subjects subtree 

                    for(var i = 0; i < numSubjects; i++) //instantiate subject subtree ui elements
                    {
                        createAccordion(subjects[i]);

                        for(var j = 0; j < numTeachers; j++)
                        {
                            for(var k = 0; k < numStudents; k++)
                            {
                                $(students[i][j][k]).css("text-align", "left");
                                createButton(students[i][j][k]).width("100%");
                            }
                        }
                    }
                }
            );
        </script>
    </body>
</html>
