<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Subject_model extends CI_Model 
{
    function getSubjects()
    {
        $this->load->database();
        return $this->db->query("SELECT * FROM subject")->result_array();
    }

    //Get Subject ID
    function getSubjectID($subname)
    {
        $this->load->database();
        $query = "SELECT Subject_id FROM subject WHERE Subject_name LIKE '".$subname."'";
        return $this->db->query($query)->result(); 
    }

    //ADD SUBJECT BY ADMIN TO DATABASE
    function addSubject($subject_data) //FROM POST
    {
        $this->load->database();
        $this->db->insert('subject', $subject_data);
        return TRUE;
    }
	   
    //DELETE SUBJECT BY ADMIN FROM DATABASE
    function deleteSubject($name)
    {
        $this->load->database();
        $query = "DELETE FROM subject WHERE Subject_name LIKE '".$name."'"; 
        $this->db->query($query);
        return TRUE;
    }
}
