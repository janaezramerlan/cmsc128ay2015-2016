<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class account extends CI_Model 
{
    public function __construct()
    {
        parent::__construct();
        //$this->load->helper('url');     
    }   
	
    function login($account_username, $account_password)
    {
        $this->load->database();
        $query = "SELECT account_username, account_password FROM account WHERE account_username = '".$account_username."' AND account_password = '".$account_password."'";
        $queryresults =  $this->db->query($query);
        
        if($queryresults-> num_rows() == 1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }//end of login function
    
    function getEmp_num($account_username, $account_password)
    {
        $this->load->database();
        $query = $this->db->query("SELECT emp_num FROM account WHERE account_username = '".$account_username."' AND account_password = '".$account_password."'");
        $row = $query->row();
        return $row->emp_num;
    }//end of getEmp_num
    
    function AddAccount($data) //FROM POST
    {
        $this->load->database();
        $this->db->insert('account', $data);
        return TRUE;
    }//end of addAccount
}
