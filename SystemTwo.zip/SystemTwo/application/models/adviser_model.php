<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Adviser_model extends CI_Model 
{
    
}
