<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Student_model extends CI_Model
{
    function getStudents()
    {
        $this->load->database();
        return $this->db->query("SELECT * FROM student")->result_array();
    }
    
    function getStudentData($studname)
    {
        $this->load->database();
        $query = "SELECT Student_id, Student_name, Student_sex, status, address, nationality, curriculum, birthdate FROM student WHERE Student_name LIKE '".$studname."'";
        $queryresults =  $this->db->query($query)->result_array();
        return $queryresults;
    }
    
    function getStudentID($studname)
    {
        $this->load->database();
        $query = "SELECT Student_id FROM students WHERE Student_name LIKE '".$studname."'";
        return $queryresults =  $this->db->query($query)->result_array();
    }
    
    function addStudent($student_data)
    {
     	$this->load->database();
     	$this->db->insert('student', $student_data);
        return TRUE;
    }
	
    function deleteStudent($name)
    {
     	$this->load->database();
        $query = "DELETE FROM student WHERE student_id = '".$name."'"; 
        $this->db->query($query);
        return TRUE;
    }
}
