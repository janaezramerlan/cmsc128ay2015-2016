<?php

class security extends CI_Controller {
	function exist($table){
	}//end of exist fucntion
}
?>