<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SubjectTeacher extends CI_Controller {

	function home(){		
		$this->load->view("subject_teacher");
	}
}

?>