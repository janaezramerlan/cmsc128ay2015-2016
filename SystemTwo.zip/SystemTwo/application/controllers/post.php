<?php 

ini_set("display_errors", 1);
error_reporting(E_ALL);

if (!defined('BASEPATH')) 
    exit('No direct script access allowed.');

class Post extends CI_Controller 
{
    public function index()
    {
        $query = $this->input->post("query");
        
        switch($query)
        {
            case "postuser":
            {
                $this->load->model("employee_model");
                
                $id = $this->input->post("id");
                $name = $this->input->post("name");
                $admin = $this->input->post("admin");
                $adviser = $this->input->post("adviser");
                $teacher = $this->input->post("teacher");
                
                $data = array
                (
                    "Emp_num" => $this->input->post("id"),
                    "name" => $this->input->post("name"),
                    "designation" => " ",
                    "Admin_flag" => $this->input->post("admin"),
                    "Adviser_flag" => $this->input->post("adviser"),
                    "Subj_teacher_flag" => $this->input->post("teacher")
                );
                
                $this->employee_model->addEmployee($data);
                
                echo '{"status" : "success"}';
                
                break;
            }
            case "poststudent":
            {
                $id = $this->input->post("id");
                $name = $this->input->post("name");
                $sex = $this->input->post("sex");
                $status = $this->input->post("status");
                $address = $this->input->post("address");
                $nationality = $this->input->post("nationality");
                $curriculum = $this->input->post("curriculum");
                $birth_day = $this->input->post("birthDay");
                $birth_month = $this->input->post("birthMonth");
                $birth_year = $this->input->post("birthYear");
                
                echo '{"status" : "success"}';
                
                break;
            }
            case "postsubject":
            {
                $id = $this->input->post("id");
                $name = $this->input->post("name");
                $desc = $this->input->post("desc");
                $type = $this->input->post("type");
                $units = $this->input->post("units");
                $start_hour = $this->input->post("startHour");
                $start_min = $this->input->post("startMin");
                $start_ampm = $this->input->post("startAMPM");
                $end_hour = $this->input->post("endHour");
                $end_min = $this->input->post("endMin");
                $end_ampm = $this->input->post("endAMPM");
                
                echo '{"status" : "success"}';
                
                break;
            }
            case "deleteentity":
            {
                $id = $this->input->post("id");
                
                switch($id)
                {
                    case "allsubjects":
                    {
                        break;
                    }
                    case "allstudents":
                    {
                        break;
                    }
                    case "allteachers":
                    {
                        break;
                    }
                    case "alladvisers":
                    {
                        break;
                    }
                    case "alladmins":
                    {
                        break;
                    }
                    default:
                    {
                        
                    }
                }
                
                echo '{"status" : "success"}';
                
                break;
            }
            case "sendmessage":
            {
                $to = $this->input->post("to");
                $content = $this->input->post("content");
                
                echo '{"status" : "success"}';
                
                break;
            }
        }
    }
}