<?php

class login extends CI_Controller {
	
	function index(){
		$this->load->view('subject_teacher');
	}
}

?>