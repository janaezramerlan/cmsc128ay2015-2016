<?php 

ini_set("display_errors", 1);
error_reporting(E_ALL);

if (!defined('BASEPATH')) 
    exit('No direct script access allowed.');

class Get extends CI_Controller 
{
    public function index()
    {
        $query = $this->input->get("query");
        
        switch($query)
        {
            case "search":
            {
                $data = array();
                
                for($i = 0; $i < 40; $i++)
                {
                    $data[$i] = "Result".$i;
                }
                
                echo json_encode($data);
                    
                break;
            }
            case "getsubjects":
            {
                $this->load->model("subject_model");
                
                $data = array();
                $subjects = $this->subject_model->getSubjects();

                for($i = 0; $i < sizeof($subjects); $i++)
                {
                    $data[$i] = array
                    (
                        "id" => $subjects[$i]["Subject_id"],
                        "name" => $subjects[$i]["Subject_name"],
                        "units" => $subjects[$i]["Subject_unit"],
                        "type" => $subjects[$i]["Subject_type"],   
                        "desc" => $subjects[$i]["Description"],
                        "startHour" => "9",
                        "startMin" => "07",
                        "startAMPM" => "AM",
                        "endHour" => "9",
                        "endMin" => "07",
                        "endAMPM" => "PM"
                    );
                }
                
                echo json_encode($data);
                
                break;
            }
            case "getteachers":
            {
                $this->load->model("employee_model");
                
                $data = array();
                $teachers = $this->employee_model->getTeachers();
                
                for($i = 0; $i < sizeof($teachers); $i++)
                {
                    $data[$i] = array
                    (
                        "id" => $teachers[$i]["Emp_num"],
                        "name" => $teachers[$i]["name"],
                        "admin" => $teachers[$i]["Admin_flag"],
                        "adviser" => $teachers[$i]["Adviser_flag"],
                        "teacher" => $teachers[$i]["Subj_teacher_flag"]
                    );
                }
                
                echo json_encode($data);
                
                break;
            }
            case "getadvisers":
            {
                $this->load->model("employee_model");
                
                $data = array();
                $advisers = $this->employee_model->getAdvisers();
                
                for($i = 0; $i < sizeof($advisers); $i++)
                {
                    $data[$i] = array
                    (
                        "id" => $advisers[$i]["Emp_num"],
                        "name" => $advisers[$i]["name"],
                        "admin" => $advisers[$i]["Admin_flag"],
                        "adviser" => $advisers[$i]["Adviser_flag"],
                        "teacher" => $advisers[$i]["Subj_teacher_flag"]
                    );
                }
                
                echo json_encode($data);
                
                break;
            }
            case "getadmins":
            {
                $this->load->model("employee_model");
                
                $data = array();
                $admins = $this->employee_model->getAdmins();
                
                for($i = 0; $i < sizeof($admins); $i++)
                {
                    $data[$i] = array
                    (
                        "id" => $admins[$i]["Emp_num"],
                        "name" => $admins[$i]["name"],
                        "admin" => $admins[$i]["Admin_flag"],
                        "adviser" => $admins[$i]["Adviser_flag"],
                        "teacher" => $admins[$i]["Subj_teacher_flag"]
                    );
                }
                
                echo json_encode($data);
                
                break;
            }
            case "getstudents":
            {
                $this->load->model("student_model");
                
                $data = array();
                $students = $this->student_model->getStudents();

                for($i = 0; $i < sizeof($students); $i++)
                {
                    $data[$i] = array
                    (
                        "id" => $students[$i]["Student_id"],
                        "name" => $students[$i]["Student_name"],
                        "sex" => $students[$i]["Student_sex"],
                        "status" => $students[$i]["status"],
                        "address" => $students[$i]["address"],
                        "nationality" => $students[$i]["nationality"],
                        "curriculum" => $students[$i]["curriculum"],
                        "birthDay" => "23",
                        "birthMonth" => "February",
                        "birthYear" => "1986"
                    );
                }
                
                echo json_encode($data);
                
                break;
            }
            case "getstudentsperteacher":
            {
                break;
            }
            case "getadvisees":
            {
                $data = array();
                
                for($i = 0; $i < 40; $i++)
                {
                    $data[$i] = array
                    (
                        "id" => "1234567890",
                        "name" => "Advisee".$i,
                        "sex" => "Female",
                        "status" => "Status",
                        "address" => "Address",
                        "nationality" => "Chinoy",
                        "curriculum" => "Dropout",
                        "birthDay" => "23",
                        "birthMonth" => "February",
                        "birthYear" => "1986"
                    );
                }
                
                echo json_encode($data);
                
                break;
            }
        }
    }
}