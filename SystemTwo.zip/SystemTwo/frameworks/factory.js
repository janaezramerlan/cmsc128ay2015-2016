/* 
 * Copyright (c) 2015, johnpaulquijano
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

/* 
    Created on : Apr 10, 2015, 11:29:13 PM
    Author     : John Paul Quijano
*/

function initPlugins()
{
    (function($)
    {
        $.fn.disableSelection = function() 
        {
            return this
            .attr("unselectable", "on")
            .css("user-select", "none")
            .on("selectstart", false);
        };
    })(jQuery);
    
    (function($)
    {
        $.fn.setCentered = function () 
        {
            return this
            .css("top", Math.max(0, (($(window).height() - $(this).outerHeight()) / 2) + $(window).scrollTop()) + "px")
            .css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) + $(window).scrollLeft()) + "px");
        };
    })(jQuery);
    
    (function($) 
    {
        $.fn.setDraggable = function() 
        {
            return this
            .mousedown
            (
                function(e) 
                {
                    var $draggable = $(this).addClass("draggable");

                    var drg_h = $draggable.outerHeight();
                    var drg_w = $draggable.outerWidth();
                    var pos_y = $draggable.offset().top + drg_h - e.pageY;
                    var pos_x = $draggable.offset().left + drg_w - e.pageX;

                    $draggable.css("z-index", 1000);

                    $("body").on("mousemove", function(e) 
                    {
                        $(".draggable")
                        .offset({top : e.pageY + pos_y - drg_h, left : e.pageX + pos_x - drg_w})
                        .on("mouseup", function(){$(this).removeClass("draggable");});
                    });
                }
            )
            .mouseup
            (
                function()
                {
                    $(this).removeClass("draggable");
                }
            );
        };
    })(jQuery);
    
    (function($)
    {
        $.fn.setToggleable = function(onToggleOn, onToggleOff) 
        {
            $(this).attr("toggle", "false");
            
            return this
            .click
            (
                function(event)
                {
                    if($(this).attr("toggle") === "false")
                    {
                        onToggleOn(event);
                        $(this).attr("toggle", "true");
                    }
                    else
                    {
                        onToggleOff(event);
                        $(this).attr("toggle", "false");
                    }

                    event.stopPropagation();
                }
            );
        };
    })(jQuery);
    
    (function($)
    {
        $.fn.initTooltip = function() 
        {
            this.find("[tooltip]")
            .each
            (
                function()
                {
                    if(!!$(this).attr("tooltip"))
                        $(this).createTooltip();
                }
            );
            
            return this;
        };
    })(jQuery);
    
    (function($)
    {
        $.fn.createTooltip = function() 
        {
            $("<div id='"+$(this).attr("id")+"Tooltip'></div>")
            .disableSelection()
            .addClass("tooltip")
            .html($(this).attr("tooltip"))
            .appendTo($(this))
            .hide();

            this
            .mouseover
            (
                function()
                {
                    $("div#"+$(this).attr("id")+"Tooltip")
                    .show()
                    .offset
                    (
                        {
                            left: $(this).offset().left + $(this).width() + 8, 
                            top: $(this).offset().top + $(this).height() + 8
                        }
                    );
                }
            )
            .mouseout
            (
                function(){$("div#"+$(this).attr("id")+"Tooltip").hide();}
            );
    
            return this;
        };
    })(jQuery);
}

function initTools()
{
    $("div.tool")
    .click
    (
        function()
        {
            $("div#"+$(this).attr("invoke")) //dialog to invoke
            .css("visibility", "visible")
            .fadeTo("fast", 1)
            .find("div.textfield").html("")
            .find("div.textarea").html("");
        }
    );
    
    $("div.floatingtool")
    .click
    (
        function(event)
        {
            $("div#"+$(this).attr("invoke"))
            .css("visibility", "visible")
            .fadeTo("fast", 1);
    
            event.stopPropagation();
        }
    )
    .mouseover
    (
        function(event)
        {
            $(this).css("border", "1px solid #ffffff");
            event.stopPropagation();
        }
    )
    .mouseout
    (
        function(event)
        {
            $(this).css("border", "1px solid transparent");
            event.stopPropagation();
        }
    );
}

function initTooltips()
{
    $("[tooltip]")
    .each
    (
        function()
        {
            if(!!$(this).attr("tooltip"))
                $(this).createTooltip();
        }
    );
}

function initFloatingToolbar()
{
    var tools = $("div#floatingtoolwrapper");
    
    $("div#floatingtoolbar")
    .setToggleable
    (
        function(event)
        {
            $(event.target).animate({width: "470px", backgroundColor: "#111111", opacity: "0.5"}, "fast");
            tools.css("display", "block");
        },
        
        function(event)
        {
            $(event.target).animate({width: "24px", backgroundColor: "#666666", opacity: "0.15"}, "fast");
            tools.css("display", "none");
        }
    );
}

function initSearch()
{
    $("div#searchfield")
    .focus
    (
        function(event)
        {
            $(this)
            .css("font-style", "normal")
            .css("color", "#444444");
            
            if($(this).html() === "Search")
                $(this).html("");

            event.stopPropagation();
        }
    )
    .blur
    (
        function(event)
        {
            if($(this).html() === "")
            {
                $(this)
                .animate({backgroundColor: "transparent"}, "fast")
                .css("font-style", "italic")
                .css("color", "#cccccc")
                .html("Search");
            }
            
            event.stopPropagation();
        }
    );
    
    $("div#floatingsearchfield")
    .click
    (
        function(event)
        {
            event.stopPropagation();
        }
    )
    .focus
    (
        function(event)
        {
            $(this)
            .animate({backgroundColor: "#555555"}, "fast")
            .css("font-style", "normal")
            .css("color", "white")
            .html("");
    
            event.stopPropagation();
        }
    )
    .blur
    (
        function(event)
        {
            if($(this).html() === "")
            {
                $(this)
                .animate({backgroundColor: "transparent"}, "fast")
                .css("font-style", "italic")
                .css("color", "#888888")
                .html("Search");
            }
            
            event.stopPropagation();
        }
    );
    
    $("div#search")
    .click
    (
        function()
        {
            var data = 
            {
                query: "search",
                key: $("div#searchfield").html()
            };

            var handler = function(response)
            {
                if(response.status === "success")
                {
                }
                else
                {
                    
                }
            };

            get(data, handler);
        }
    );
    
    $("div#floatingsearch")
    .click
    (
        function()
        {
            var data = 
            {
                query: "search",
                key: $("div#floatingsearchfield").html()
            };

            var handler = function(response)
            {
                if(response.status === "success")
                {
                    
                }
                else
                {
                    
                }
            };

            get(data, handler);
        }
    );
}

function initDialogs()
{
    $("div.dialog")
    .each
    (
        function()
        {
            var $dialog = $(this);
            
            $dialog
            .setDraggable()
            .mousedown
            (
                function() //emulate focus
                {
                    $(this).css("z-index", "8");
                    
                    $("div.dialog").not(this)
                    .each(function(){$(this).css("z-index", "7");});
                }
            );
        }
    )
    .setCentered()
    .hide();
    
    $("div.dialogclosebutton")
    .each
    (
        function()
        {
            $(this)
            .click
            (
                function(event)
                {
                    $(this).parent().parent().fadeTo("fast", 0, function(){$(this).hide();});
                    event.stopPropagation();
                }
            )
            .mouseover
            (
                function(event)
                {
                    $(this).animate({backgroundColor: "#ff0000"}, "fast");
                    event.stopPropagation();
                }
            )
            .mouseout
            (
                function(event)
                {
                    $(this).animate({backgroundColor: "#ffffff"}, "fast");
                    event.stopPropagation();
                }
            );
        }
    );
    
    $("div.dialogokbutton") //submit
    .each
    (
        function()
        {
            $(this)
            .click
            (
                function(event)
                {
                    var data = {};
                    var $dialog = $(this).parent().parent();

                    switch($dialog.attr("id"))
                    {
                        case "messagedialog":
                        {
                            data.query = "sendmessage";
                            data.to = $("div#messagetotextfield").html();
                            data.content = $("div#messagecontenttextarea").html();
                            
                            var handler = function(response)
                            {
                                if(response.status === "success")
                                    showNotification("Message sent.");
                                else
                                    showNotification("Failed to send message.");
                            };
                            
                            post(data, handler);
                            
                            break;
                        }
                        case "adduserdialog":
                        {
                            data.query = "postuser";
                            data.id = $("div#adduseridtextfield").html();
                            data.name = $("div#addusernametextfield").html();
                            
                            data.teacher = $("div#adduserteacherbutton").attr("select");
                            data.adviser = $("div#adduseradviserbutton").attr("select");
                            data.admin = $("div#adduseradminbutton").attr("select");
                            
                            handler = function(response)
                            {
                                if(response.status === "success")
                                    showNotification("User data saved.");
                                else
                                    showNotification("Failed to save user data.");
                            };
                            
                            post(data, handler);
                            
                            break;
                        }
                        case "addsubjectdialog":
                        {
                            data.query = "postsubject";
                            data.id = $("div#adduseridtextfield").html();
                            data.name = $("div#addusernametextfield").html();
                            data.desc = $("div#addsubjectdesctextarea").html();
                            data.type = $("div.addsubjecttypebutton[select='true']").html();
                            data.units = $("div#addsubjectunitstextfield").html();
                            data.startHour = $("div#addsubjectstarthourbutton").html();
                            data.startMin = $("div#addsubjectstartminbutton").html();
                            data.startAMPM = $("div#addsubjectstartampmbutton").html();
                            data.endHour = $("div#addsubjectendhourbutton").html();
                            data.endMin = $("div#addsubjectendminbutton").html();
                            data.endAMPM = $("div#addsubjectendampmbutton").html();

                            handler = function(response)
                            {
                                if(response.status === "success")   
                                    showNotification("Subject data saved.");
                                else
                                    showNotification("Failed to save subject data.");
                            };
                            
                            post(data, handler);
                            
                            break;
                        }
                        case "addstudentdialog":
                        {
                            data.query = "poststudent";
                            data.id = $("div#addstudentidtextfield").html();
                            data.name = $("div#addstudentnametextfield").html();
                            data.sex = $("div.addstudentsexbutton[select='true']").html();
                            data.address = $("div#addstudentaddresstextfield").html();
                            data.nationality = $("div#addstudentnattextfield").html();
                            data.curriculum = $("div#addstudentcurrtextfield").html();
                            data.status = $("div#addstudentstatustextfield").html();
                            data.birthDay = $("div#addstudentbdatedaybutton").html();
                            data.birthMonth = $("div#addstudentbdatemonthbutton").html();
                            data.birthYear = $("div#addstudentbdateyearbutton").html();
                            
                            handler = function(response)
                            {
                                if(response.status === "success")   
                                    showNotification("Student data saved.");
                                else
                                    showNotification("Failed to save student data.");
                            };
                            
                            post(data, handler);
                            
                            break;
                        }
                        case "confirmdeletedialog":
                        {
                            data.query = "deleteentity";
                            data.id = $dialog.attr("entityid");
                            
                            handler = function(response)
                            {
                                if(response.status === "success")
                                {
                                    showNotification("Entity deleted.");
                                    refreshContent($("div#"+$dialog.attr("contentpane")), $dialog.attr("contenttype"));
                                }
                                else
                                    showNotification("Failed to delete entity.");
                            };
                            
                            post(data, handler);
                        }
                    }
                    
                    $dialog.fadeTo("fast", 0, function(){$(this).hide();});
                    event.stopPropagation();
                }
            )
            .mouseover
            (
                function(event)
                {
                    $(this).animate({backgroundColor: "#00ff00"}, "fast");
                    event.stopPropagation();
                }
            )
            .mouseout
            (
                function(event)
                {
                    $(this).animate({backgroundColor: "#ffffff"}, "fast");
                    event.stopPropagation();
                }
            );
        }
    );
    
    $("div.dialog").find("div[contenteditable='true']") //prevent dragging when editing fields
    .each
    (
        function()
        {
            $(this)
            .mousedown
            (
                function(event)
                {
                    var $dialog = $(this).parent().parent();
                    
                    //emulate focus on parent dialog
                    $dialog.css("z-index", "8");
                    $("div.dialog").not($dialog)
                    .each(function(){$(this).css("z-index", "7");});
            
                    event.stopPropagation();
                }
            );
        }
    );
}

function selectRadioButton(id)
{
    var $button = $(id);
    
    if($button.hasClass("radio"))
    {
        //select this button
        $button.attr("select", "true");
        $button.animate({color: "#444444", backgroundColor: "#dddddd"}, "fast");
        
        //deselect other buttons in the group
        $("div.button.radio[group='"+$button.attr("group")+"']").not($button).each
        (
            function()
            {
                $(this).attr("select", "false").animate({color: "#bbbbbb", backgroundColor: "#888888"}, "fast");
            }
        );
    }
}

function toggleButton(id)
{
    var $button = $(id);
    
    if($button.hasClass("toggle"))
        $button.attr("select", "1").animate({color: "#444444", backgroundColor: "#dddddd"}, "fast");
}

function untoggleButton(id)
{
    var $button = $(id);
    
    if($button.hasClass("toggle"))
        $button.attr("select", "0").animate({color: "#bbbbbb", backgroundColor: "#888888"}, "fast");
}

function initButtons()
{
    $("div.button")
    .each
    (
        function()
        {
            if($(this).hasClass("toggle"))
            {
                $(this).setToggleable
                (
                    function(event)
                    {
                        $(event.target)
                        .attr("select", "1")
                        .animate({color: "#444444", backgroundColor: "#dddddd"}, "fast");
                    }, 

                    function(event)
                    {
                        $(event.target)
                        .attr("select", "0")
                        .animate({color: "#bbbbbb", backgroundColor: "#888888"}, "fast");
                    }
                )
                .mouseover
                (
                    function(event)
                    {
                        if($(this).attr("toggle") === "false")
                            $(this).animate({color: "#666666", backgroundColor: "#aaaaaa"}, "fast");

                        event.stopPropagation();
                    }
                )
                .mouseout
                (
                    function(event)
                    {
                        if($(this).attr("toggle") === "false")
                            $(this).animate({color: "#bbbbbb", backgroundColor: "#888888"}, "fast");

                        event.stopPropagation();
                    }
                );
            }
            else if($(this).hasClass("radio"))
            {
                $(this)
                .mouseover
                (
                    function(event)
                    {
                        if($(this).attr("select") === "false")
                            $(this).animate({color: "#666666", backgroundColor: "#aaaaaa"}, "fast");

                        event.stopPropagation();
                    }
                )
                .mouseout
                (
                    function(event)
                    {
                        if($(this).attr("select") === "false")
                            $(this).animate({color: "#bbbbbb", backgroundColor: "#888888"}, "fast");

                        event.stopPropagation();
                    }
                )
                .click
                (
                    function(event)
                    {
                        //select this button
                        $(this).attr("select", "true");
                        $(this).animate({color: "#444444", backgroundColor: "#dddddd"}, "fast");
                        
                        //deselect other buttons in the group
                        $("div.button.radio[group='"+$(this).attr("group")+"']").not($(this)).each
                        (
                            function()
                            {
                                $(this).attr("select", "false").animate({color: "#bbbbbb", backgroundColor: "#888888"}, "fast");
                            }
                        );

                        event.stopPropagation();
                    }
                );
            }
            else
            {
                $(this)
                .mouseover
                (
                    function(event)
                    {
                        $(this).animate({color: "#666666", backgroundColor: "#aaaaaa"}, "fast");
                        event.stopPropagation();
                    }
                )
                .mouseout
                (
                    function(event)
                    {
                        $(this).animate({color: "#444444", backgroundColor: "#dddddd"}, "fast");
                        event.stopPropagation();
                    }
                );
            }
        }
    );
    
    $("div.toggleampm").click
    (
        function()
        {
            $(this).disableSelection();
            
            if($(this).html() === "AM")
                $(this).html("PM");
            else
                $(this).html("AM");
        }
    );
}

function initContentTabs()
{
    $("div.contenttab")
    .each
    (
        function()
        {
            var tab = $(this);
            
            tab
            .click
            (
                function(event)
                {
                    var data = {};
                    var icon = tab.find("div.tabicon");
                    var firstLevel = $("div#firstlevelresult");
                    var secondLevel = $("div#secondlevelresult");
                    var thirdLevel = $("div#thirdlevelresult");
                    
                    //clear content
                    firstLevel.empty().css("opacity", "0").css("min-height", $("div#tabspanel").height()+"px");
                    secondLevel.empty().css("opacity", "0").css("min-height", $("div#tabspanel").height()+"px");
                    thirdLevel.empty().css("opacity", "0").css("min-height", $("div#tabspanel").height()+"px");
                    
                    //mark selected tab
                    icon.css("opacity", "1");
                    tab.css("border-top", "1px solid #ff7722").css("border-bottom", "1px solid #ff7722").css("border-left", "1px solid #ff7722");
                    
                    //deselect other tabs
                    $("div.contenttab").not(tab)
                    .css("border-top", "1px solid transparent")
                    .css("border-bottom", "1px solid transparent")
                    .css("border-left", "1px solid transparent")
                    .find("div.tabicon")
                    .css("opacity", "0");
                    
                    switch(event.target.id) //process content request
                    {
                        case "subjectstab":
                        {
                            data.query = "getsubjects";

                            var handler = function(response)
                            {
                                for(var i = 0; i < response.length; i++)
                                    createContent(firstLevel, "subject"+i, "subject", response[i].name, response[i]);
                            };

                            get(data, handler);
                            
                            break;
                        }
                        case "teacherstab":
                        {
                            data.query = "getteachers";
                            
                            var handler = function(response)
                            {
                                for(var i = 0; i < response.length; i++)
                                    createContent(firstLevel, "teacher"+i, "teacher", response[i].name, response[i]);
                            };

                            get(data, handler);
                            
                            break;
                        }
                        case "adviserstab":
                        {
                            data.query = "getadvisers";
                            
                            var handler = function(response)
                            {
                                for(var i = 0; i < response.length; i++)
                                    createContent(firstLevel, "adviser"+i, "adviser", response[i].name, response[i]);
                            };

                            get(data, handler);
                            
                            break;
                        }
                        case "studentstab":
                        {
                            data.query = "getstudents";
                            
                            var handler = function(response)
                            {
                                for(var i = 0; i < response.length; i++)
                                    createContent(firstLevel, "student"+i, "student", response[i].name, response[i]);
                            };

                            get(data, handler);
                            
                            break;
                        }
                        case "adminstab":
                        {
                            data.query = "getadmins";
                            
                            var handler = function(response)
                            {
                                for(var i = 0; i < response.length; i++)
                                    createContent(firstLevel, "admin"+i, "admin", response[i].name, response[i]);
                            };

                            get(data, handler);
                            
                            break;
                        }
                        case "yearleveltab":
                        {
                            createContent(firstLevel, "yearlevel"+0, "yearlevel", "Freshman");
                            createContent(firstLevel, "yearlevel"+1, "yearlevel", "Sophomore");
                            createContent(firstLevel, "yearlevel"+2, "yearlevel", "Junior");
                            createContent(firstLevel, "yearlevel"+3, "yearlevel", "Senior");
                            
                            break;
                        }
                    }
                    
                    firstLevel.fadeTo("fast", 1);

                    event.stopPropagation();
                }
            );
    
            $(this).find("div.tabdeleteicon")
            .click
            (
                function(event)
                {
                    $("div#confirmdeletedialog")
                    .attr("contenttype", $(this).attr("contenttype"))
                    .attr("contentpane", "firstlevelresult")
                    .attr("entityid", "all" + $(this).attr("contenttype") + "s")
                    .css("visibility", "visible")
                    .fadeTo("fast", 1);

                    //mark selected item
                    tab.find("div.tabicon").css("opacity", "1");
                    tab.css("border-top", "1px solid #ff7722").css("border-bottom", "1px solid #ff7722").css("border-left", "1px solid #ff7722");

                    //deselect other items
                    $("div.contenttab").not(tab)
                    .css("border-top", "1px solid transparent")
                    .css("border-bottom", "1px solid transparent")
                    .css("border-left", "1px solid transparent")
                    .find("div.tabicon")
                    .css("opacity", "0");
                    
                    event.stopPropagation();
                }
            );
        }
    );
}

function createContent(panel, id, type, text, entitydata)
{
    var $cardicon = null;
    var $tabicon = $("<div class='tabicon'></div>");
    var $editicon = $("<div id='edit"+id+"'class='editicon resulticon' tooltip='Edit'></div>");
    var $deleteicon = $("<div id='delete"+id+"'class='deleteicon resulticon' tooltip='Delete'></div>");
    var $content = $("<div id='"+id+"' class='resultitem contenttab "+type+"'>"+text+"</div>").append($tabicon);

    $content.append($deleteicon);
    
    if(type === "student")
    {
        $cardicon = $("<div id='card"+id+"'class='cardicon resulticon' tooltip='Generate Report Card'></div>");
        $content.append($cardicon);
    }
    
    $content.append($editicon);

    $content
    .click
    (
        function()
        {
            var data = {};
            var $nextLevel = null;
            var panelID = panel.attr("id");
            
            //establish next level panel and reset content of succeeding levels
            if(panelID === "firstlevelresult")
            {
                $nextLevel = $("div#secondlevelresult").empty().css("opacity", "0").css("min-height", $("div#firstlevelresult").height()+"px");
                $("div#thirdlevelresult").empty().css("opacity", "0");
            }
            else if(panelID === "secondlevelresult")
                $nextLevel = $("div#thirdlevelresult").empty().css("opacity", "0").css("min-height", $("div#secondlevelresult").height()+"px");
            
            //mark selected item
            $tabicon.css("opacity", "1");
            $content.css("border-top", "1px solid #ff7722").css("border-bottom", "1px solid #ff7722");

            //deselect other items
            panel.find("div.contenttab").not($content)
            .css("border-top", "1px solid transparent")
            .css("border-bottom", "1px solid transparent")
            .find("div.tabicon")
            .css("opacity", "0");
            
            switch(type)
            {
                case "subject":
                {
                    data.query = "getteachers";
                            
                    var handler = function(response)
                    {
                        for(var i = 0; i < response.length; i++)
                            createContent($nextLevel, "teacher"+i, "teacher", response[i].name, response[i]);
                    };

                    get(data, handler);

                    break;
                }
                case "teacher":
                {
                    data.query = "getstudentsperteacher";
                            
                    var handler = function(response)
                    {
                        for(var i = 0; i < response.length; i++)
                            createContent($nextLevel, "student"+i, "student", response[i].name, response[i]);
                    };

                    get(data, handler);

                    break;
                }
                case "adviser":
                {
                    data.query = "getadvisees";
                            
                    var handler = function(response)
                    {
                        for(var i = 0; i < response.length; i++)
                            createContent($nextLevel, "advisee"+i, "student", response[i].name, response[i]);
                    };

                    get(data, handler);

                    break;
                }
                case "student":
                {
                    
                }
                case "admin":
                {
                    
                }
            }
            
            if($nextLevel !== null)
                $nextLevel.fadeTo("fast", 1);
        }
    )
    .initTooltip()
    .disableSelection();
    
    if($cardicon !== null)
    {
        $editicon
        .click
        (
            function(event)
            {
                event.stopPropagation();
            }
        );
    }
    
    $editicon
    .click
    (
        function(event)
        {
            var $dialog = null;

            if(type === "subject")
            {
                $dialog = $("div#addsubjectdialog").css("visibility", "visible").fadeTo("fast", 1);

                if(entitydata.type === "Regular")
                    selectRadioButton("div#addsubjectregularbutton");
                else
                    selectRadioButton("div#addsubjecthomeroombutton");

                $("div#addsubjectidtextfield").html(entitydata.id);
                $("div#addsubjectnametextfield").html(entitydata.name);
                $("div#addsubjectdesctextarea").html(entitydata.desc);
                $("div#addsubjectunitstextfield").html(entitydata.units);
                $("div#addsubjectstarthourbutton").html(entitydata.startHour);
                $("div#addsubjectstartminbutton").html(entitydata.startMin);
                $("div#addsubjectstartampmbutton").html(entitydata.startAMPM);
                $("div#addsubjectendhourbutton").html(entitydata.endHour);
                $("div#addsubjectendminbutton").html(entitydata.endMin);
                $("div#addsubjectendampmbutton").html(entitydata.endAMPM);
            }
            else if(type === "student")
            {
                $dialog = $("div#addstudentdialog").css("visibility", "visible").fadeTo("fast", 1);

                if(entitydata.sex === "Male")
                    selectRadioButton("div#addstudentmalebutton");
                else
                    selectRadioButton("div#addstudentfemalebutton");

                $("div#addstudentidtextfield").html(entitydata.id);
                $("div#addstudentnametextfield").html(entitydata.name);
                $("div#addstudentaddresstextfield").html(entitydata.address);
                $("div#addstudentnattextfield").html(entitydata.nationality);
                $("div#addstudentcurrtextfield").html(entitydata.curriculum);
                $("div#addstudentstatustextfield").html(entitydata.status);
                $("div#addstudentbdatedaybutton").html(entitydata.birthDay);
                $("div#addstudentbdatemonthbutton").html(entitydata.birthMonth);
                $("div#addstudentbdateyearbutton").html(entitydata.birthYear);
            }
            else if(type === "teacher" || type === "adviser" || type === "admin")
            {
                $dialog = $("div#adduserdialog").css("visibility", "visible").fadeTo("fast", 1);

                $("div#adduseridtextfield").html(entitydata.id);
                $("div#addusernametextfield").html(entitydata.name);

                if(entitydata.teacher === "1")
                    toggleButton("div#adduserteacherbutton");
                else
                    untoggleButton("div#adduserteacherbutton");

                if(entitydata.adviser === "1")
                    toggleButton("div#adduseradviserbutton");
                else
                    untoggleButton("div#adduseradviserbutton");

                if(entitydata.admin === "1")
                    toggleButton("div#adduseradminbutton");
                else
                    untoggleButton("div#adduseradminbutton");
            }

            //mark selected item
            $tabicon.css("opacity", "1");
            $content.css("border-top", "1px solid #ff7722").css("border-bottom", "1px solid #ff7722");

            //deselect other items
            panel.find("div.contenttab").not($content)
            .css("border-top", "1px solid transparent")
            .css("border-bottom", "1px solid transparent")
            .find("div.tabicon")
            .css("opacity", "0");

            event.stopPropagation();
        }
    );
    
    $deleteicon
    .click
    (
        function(event)
        {
            var $nextLevel = null;
            
            //establish next level panel
            if(panel.attr("id") === "firstlevelresult")
                $nextLevel = $("div#secondlevelresult");
            else if(panel.attr("id") === "secondlevelresult")
                $nextLevel = $("div#thirdlevelresult");
            
            $("div#confirmdeletedialog")
            .attr("contenttype", type)
            .attr("contentpane", panel.attr("id"))
            .attr("entityid", entitydata.id)
            .css("visibility", "visible")
            .fadeTo("fast", 1);
            
            //mark selected item
            $tabicon.css("opacity", "1");
            $content.css("border-top", "1px solid #ff7722").css("border-bottom", "1px solid #ff7722");
            
            //deselect other items
            panel.find("div.contenttab").not($content)
            .css("border-top", "1px solid transparent")
            .css("border-bottom", "1px solid transparent")
            .find("div.tabicon")
            .css("opacity", "0");
            
            event.stopPropagation();
        }
    );
    
    if(panel !== null)
        panel.append($content);
    
    return $content;
}

function refreshContent(panel, type)
{
    var data = {};
    var panelID = panel.attr("id");
    
    panel.empty();
    
    if(panelID === "firstlevelresult")
    {
        $("div#secondlevelresult").empty().css("opacity", "0").css("min-height", $("div#firstlevelresult").height()+"px");
        $("div#thirdlevelresult").empty().css("opacity", "0");
    }
    else if(panelID === "secondlevelresult")
        $("div#thirdlevelresult").empty().css("opacity", "0").css("min-height", $("div#secondlevelresult").height()+"px");

    switch(type)
    {
        case "subject":
        {
            data.query = "getsubjects";
            
            var handler = function(response)
            {
                for(var i = 0; i < response.length; i++)
                    createContent(panel, "subject"+i, "subject", response[i].name, response[i]);
            };

            get(data, handler);

            break;
        }
        case "student":
        {
            data.query = "getstudents";
            
            var handler = function(response)
            {
                for(var i = 0; i < response.length; i++)
                    createContent(panel, "student"+i, "student", response[i].name, response[i]);
            };

            get(data, handler);

            break;
        }
        case "teacher":
        {
            data.query = "getteachers";
            
            var handler = function(response)
            {
                for(var i = 0; i < response.length; i++)
                    createContent(panel, "teacher"+i, "teacher", response[i].name, response[i]);
            };

            get(data, handler);

            break;
        }
        case "adviser":
        {
            data.query = "getadvisers";
            
            var handler = function(response)
            {
                for(var i = 0; i < response.length; i++)
                    createContent(panel, "adviser"+i, "adviser", response[i].name, response[i]);
            };

            get(data, handler);

            break;
        }
        case "advisee":
        {
            data.query = "getadvisees";
            
            var handler = function(response)
            {
                for(var i = 0; i < response.length; i++)
                    createContent(panel, "advisee"+i, "student", response[i].name, response[i]);
            };

            get(data, handler);

            break;
        }
        case "admin":
        {
            data.query = "getadmins";
            
            var handler = function(response)
            {
                for(var i = 0; i < response.length; i++)
                    createContent(panel, "admin"+i, "admin", response[i].name, response[i]);
            };

            get(data, handler);

            break;
        }
    }
    
    panel.fadeTo("fast", 1);
}

function initMenus()
{
    $("div.menuinvoker")
    .each
    (
        function()
        {
            var $invoker = $(this);

            $("div#"+$invoker.attr("invoke")).attr("invoker", $invoker.attr("id"));

            $invoker.click
            (
                function(event)
                {
                    var $menu = $("div#"+$invoker.attr("invoke"))
                    .css("opacity", "0.9")
                    .slideToggle
                    (
                        "fast",

                        function() //called when animatin completes
                        {
                            var menuOffset = $menu.offset().top + $menu.outerHeight();

                            if(menuOffset > window.innerHeight+window.scrollY) //part of menu is outside viewport, adjust position
                                $menu.animate({top: $menu.offset().top - (menuOffset - window.innerHeight)}, "fast");
                        }
                    )
                    .offset
                    (
                        {
                            left: $invoker.offset().left,
                            top: $invoker.offset().top + $(this).outerHeight()
                        }
                    );

                    event.stopPropagation();
                }
            );
        }
    );
    
    $("div.menu")
    .each
    (
        function()
        {
            var $menu = $(this);
            
            $menu
            .mouseleave
            (
                function(event)
                {
                    $menu.slideUp("fast");
                    event.stopPropagation();
                }
            );
        }
    )
    .hide();
    
    $("div.menuitem")
    .each
    (
        function()
        {
            $(this)
            .click
            (
                function(event)
                {
                    $("div#"+$(event.target).parent().attr("invoker")).html($(event.target).html());
                    $(event.target).parent().fadeTo("fast", 0, function(){$(this).hide();});
                    
                    event.stopPropagation();
                }
            )
            .css("min-width", $("div#"+$(this).parent().attr("invoker")).outerWidth());
        }
    );
}

function showNotification(message)
{
    $("div#notification")
    .html(message)
    .css("visibility", "visible")
    .fadeTo("slow", 0.80)
    .setCentered()
    .delay(600)
    .fadeTo("slow", 0, function(){$(this).css("visibility", "hidden");});
}

function post(data, success, error, complete) //ajax wrapper
{
    $.ajax
    (
        {
            data: data,
            type: "POST",
            dataType: "json",
            success: success,
            error: error,
            complete: complete,
            url: "../index.php/post"
        }
    );
}

function get(data, success, error, complete) //ajax wrapper
{
    $.ajax
    (
        {
            data: data,
            type: "GET",
            dataType: "json",
            success: success,
            error: error,
            complete: complete,
            url: "../index.php/get"
        }
    );
}

function initialize()
{
    initPlugins();
    initTools();
    initTooltips();
    initDialogs();
    initButtons();
    initMenus();
    initSearch();
    initContentTabs();
    initFloatingToolbar();
    
    $("div#header").disableSelection();
    $("div#userpanel").disableSelection();
    $("div#tabspanel").disableSelection();
    $("div#copyright").disableSelection();
}