<?php

class student extends CI_Controller {
	

	function index()
	{
	}
	function LoadAddStudent(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('add_student');
	}//end of LoadAddSubject function
	function LoadDeleteStudent(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('delete_student');
	}//end of LoadDeleteSubject function
	function LoadEditStudent(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('editStudent');
	}//end of LoadDeleteSubject function
	
	function AddStudent(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('student_model');
		$this->load->helper('date');
		$this->load->library('session');
		$this->load->model('logs_model');
		//FORM VALIDATION
		$this->form_validation->set_rules('stud_name', 'Student Name', 'required');
		$this->form_validation->set_rules('stud_sex', 'Student Sex', 'required');
		$this->form_validation->set_rules('stud_status', 'Student Status', 'required');
		$this->form_validation->set_rules('stud_address', 'Student Address', 'required');
		$this->form_validation->set_rules('stud_nationality', 'Student Nationality', 'required');
		$this->form_validation->set_rules('stud_curri', 'Student Curriculum', 'required');
		$this->form_validation->set_rules('stud_bday', 'Student Birthday', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('add_student');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			//GET USER INPUT
			$student_data = array(
							'Student_name' => $this->input->post('stud_name'),
							'Student_sex' => $this->input->post('stud_sex'),
							'status' => $this->input->post('stud_status'),
							'address' => $this->input->post('stud_address'),
							'nationality' => $this->input->post('stud_nationality'),
							'curriculum' => $this->input->post('stud_curri'),
							//birthdate doesn't work atm
							'birthdate' => $this->input->post('stud_bday')
			);

				//CALL ADD STUDENT FUNCTION
				$result = $this->student_model->addStudent($student_data);
				//IF SUCCESSFUL ADDING SUBJECT GO TO HOME
				if($result){
					$emp_num = $this->session->userdata('emp_num');
				
				//--------------------------for logs---------------------------------//
					$format = 'DATE_ATOM';
					$time = time();
					$data2 = array(
                	   'date'  => standard_date($format, $time),
                	   'emp_num'  => $emp_num,
                	   'activity' => 'Added Student',
					   'remarks' => $this->input->post('stud_name')
					);
					$this->logs_model->AddLogs($data2);
			
					$this->load->view('formsuccess');
				}
			
		}
			
				
	}//end of add subject function
	
	function DeleteStudent(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('student_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('name', 'Student Name', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('delete_student');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			
			$student_id = $this->input->post('name');

			//-------------------------CHECK IF STUDENT EXISTS-------------------//
			$table = "student";
			$attribute = "Student_id";
			$this->load->model('account');
			$result2 = $this->account->exist($table,$student_id, $attribute);

			if($result2){
				//CALL DELETE STUDENT FUNCTION
				$result = $this->student_model->deleteStudent($student_id);
				//IF SUCCESSFUL DELETING STUDENT GO TO HOME
				if($result){
					$this->load->helper('date');
					$this->load->library('session');
					$this->load->model('logs_model');
				
					//--------------------------for logs---------------------------------/
					$data2 = array(
                		'date'  => standard_date('DATE_ATOM', time()),
                 		'emp_num'  => $this->session->userdata('emp_num'),
                		'activity' => 'Deleted Student',
						'remarks' => $this->input->post('name')
					);
					$this->logs_model->AddLogs($data2);
			
					$this->load->view('formsuccess');
				}
			}
			else{
				$this->load->view('formsuccess'); //go back to home
			}
		}				
	}//end of delete student function

	function EditStudent(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('student_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('Student_id', 'Student ID', 'required');
		$this->form_validation->set_rules('Student_name', 'Student Name', 'required');
		$this->form_validation->set_rules('Student_sex', 'Sex', 'required');
		$this->form_validation->set_rules('status', 'Status', 'required');
		$this->form_validation->set_rules('address', 'Address', 'required');
		$this->form_validation->set_rules('nationality', 'Nationality', 'required');
		$this->form_validation->set_rules('curriculum', 'Curriculum', 'required');
		$this->form_validation->set_rules('birthdate', 'Date Of Birth', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO EDIT STUDENT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('editStudent');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			$data = array(
							'Student_name' => $this->input->post('Student_name'),
							'Student_sex' => $this->input->post('Student_sex'),
							'status' => $this->input->post('status'),
							'address' => $this->input->post('address'),
							'nationality' => $this->input->post('nationality'),
							'curriculum' => $this->input->post('curriculum'),
							'birthdate' => $this->input->post('birthdate')
			);
			$student_id = $this->input->post('Student_id');

			$table = "student";
			$attribute = "student_id";
			$this->load->model('account');
			$result2 = $this->account->exist2($table,$student_id, $attribute);

			if($result2){
				$this->load->model('edit_history');
				$this->load->helper('date');
				$this->load->library('session');
				$this->load->model('logs_model');
			
				//GET PREVIOUS DATA FROM DB
				$result = $this->student_model->getData($student_id);
				
				foreach($result as $row): 
				//query per student
					$content = $row->Student_id;
					$content .= "   ";
					$content .= $row->Student_name;
					$content .= "   ";
					$content .= $row->Student_sex;
					$content .= "   ";
					$content .= $row->status;
					$content .= "   ";
					$content .= $row->nationality;
					$content .= "   ";
					$content .= $row->curriculum;
					$content .= "   ";
					$content .= $row->birthdate;
				endforeach;
				
				//ADD TO EDIT HISTORY TABLE 
				$data2 = array(
					   'date'  => standard_date('DATE_ATOM', time()),
					   'emp_num'  => $this->session->userdata('emp_num'),
					   'page' => 'edit student',
					   'remarks' => $content 
				);

				$this->edit_history->AddData($data2);
			
				//CALL EDIT STUDENT FUNCTION
				$result = $this->student_model->editStudent($data,$student_id);
				//IF SUCCESSFUL EDITING STUDENT  GO TO HOME
				if($result){
					$this->load->helper('date');
					$this->load->library('session');
					$this->load->model('logs_model');
				
					//--------------------------for logs---------------------------------/
					$data2 = array(
              	     'date'  => standard_date('DATE_ATOM', time()),
              	     'emp_num'  => $this->session->userdata('emp_num'),
              	     'activity' => 'Edited Student',
					   'remarks' => $student_id
					);
					$this->logs_model->AddLogs($data2);
					$this->load->view('formsuccess');
				}
			}
			else{
				$this->load->view('formsuccess'); //go back to home
			}
		}				
	}//end of edit student  function

	
}

?>