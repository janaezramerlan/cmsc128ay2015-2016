<?php

class report extends CI_Controller {
	

	function index()
	{
	}
	function LoadReport(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('report_card');
	}
	function loadListSection(){
		$this->load->helper(array('form', 'url'));
		$this->load->view('listOfSection');
	}//end of function
	
	function loadListYear(){
		$this->load->helper(array('form', 'url'));
		$this->load->view('listOfYear');
	}//end of function
	
	function GenerateListSection(){
		$this->load->helper('date');
		$this->load->library('session');
		$this->load->model('logs_model');
		
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	
		//FORM VALIDATION
		$this->form_validation->set_rules('section', 'Section', 'required');
		$this->form_validation->set_rules('subject_id', 'Subject Id', 'required');
		$this->form_validation->set_rules('grade_period', 'Grading Period', 'required');
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('listOfSection');
		}
		else{
			$this->load->model('report_model');
			$section = $this->input->post('section');
			$subject_id = $this->input->post('subject_id');
			$grading_period= $this->input->post('grade_period');
			$result = $this->report_model->listOfSectionWithGrade($section,$subject_id, $grading_period);
			$content  = "<center> <br> <b>SECTION: </b>";
			$content .= $section;
			$content .= "   <b>SUBJECT: </b>";
			$content .= $subject_id;
			$content .= "   <b>GRADING PERIOD: </b> ";
			$content .= $grading_period;
			$content.="<br>";
			$cnt=0;
			foreach($result as $row): 
				//$content.="<center>";
				$content .= $row->student_id;
				$content .= '        ';
				$content .= $row->grade;
				$content .="<br>";
				$cnt++;
			endforeach;
			$content.="<center><b>TOTAL STUDENTS:</b>";
			$content.=$cnt;
			//IF SUCCESSFUL LISTING GO TO HOME
			$this->load->view('formsuccess');
			
			include_once('dompdf/dompdf_config.inc.php');
			$dompdf = new DOMPDF();
			$dompdf->load_html($content);
			$dompdf->render();
			$dompdf->stream('listofsectionwithgrade.pdf');
			
			
			
			//--------------------------for logs---------------------------------/
			$data2 = array(
					   'date'  => standard_date('DATE_ATOM', time()),
					   'emp_num'  => $this->session->userdata('emp_num'),
					   'activity' => 'Generate List',
					   'remarks' => $section.' '.$subject_id.' '.$grading_period
			);
			$this->logs_model->AddLogs($data2);
		}
	}//end of function

	function GenerateListYear(){
		$this->load->helper('date');
		$this->load->library('session');
		$this->load->model('logs_model');
		
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
	
		//FORM VALIDATION
		$this->form_validation->set_rules('year', 'year', 'required');
		$this->form_validation->set_rules('subject_id', 'Subject Id', 'required');
		$this->form_validation->set_rules('grade_period', 'Grading Period', 'required');
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('listOfSection');
		}
		else{
			$this->load->model('report_model');
			$year = $this->input->post('year');
			$subject_id = $this->input->post('subject_id');
			$grading_period= $this->input->post('grade_period');
			$result = $this->report_model->listOfYearWithGrade($year,$subject_id, $grading_period);
			
			
			$content = "<center> <br><b>YEAR: </b>";
			$content .= $year;
			$content .= "   <b>SUBJECT: </b>";
			$content .= $subject_id;
			$content .= "   <b>GRADING PERIOD: </b>";
			$content .= $grading_period;
			$content.="<br>";
			$cnt=0;
			foreach($result as $row): 
				$content .= $row->student_id;
				$content .= '         ';
				$content .= $row->grade;
				$content .="<br>";
				$cnt++;
			endforeach;
			$content.="<b>TOTAL STUDENTS:</b>";
			$content.=$cnt;
			
			include_once('dompdf/dompdf_config.inc.php');
			$dompdf = new DOMPDF();
			$dompdf->load_html($content);
			$dompdf->render();
			$dompdf->stream('listofsectionwithgrade.pdf');
			
			//IF SUCCESSFUL LISTING GO TO HOME
			$this->load->view('formsuccess');
			
			//--------------------------for logs---------------------------------/
			$data2 = array(
					   'date'  => standard_date('DATE_ATOM', time()),
					   'emp_num'  => $this->session->userdata('emp_num'),
					   'activity' => 'Generate List',
					   'remarks' => $year.' '.$subject_id.' '.$grading_period
			);
			$this->logs_model->AddLogs($data2);
		}
	}//end of function

	//--------------------------REPORT CARD RELATED---------------------------------//
	function SearchStudent(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('report_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('stud_id', 'Student ID', 'required');
		$this->form_validation->set_rules('batch_id', 'Batch ID', 'required');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('report_card');
		}
		else
		{
			//GET USER INPUT
			$data1 = $this->input->post('stud_id');
			$data2 = $this->input->post('batch_id');

			$result['students'] = $this->report_model->getStudentData($data1, $data2);
			$count = 0;

			//declaration of variables
			$student_name = "";
			$start_of_acad = "";
			$end_of_acad = "";
			$s_year = "";
			$s_section = "";
			$s_nat = "";
			$s_gender = "";
			$s_age = "";
			$string = "<center><b>UNIVERSITY OF THE PHILIPPINES RURAL HIGH SCHOOL</b></center>
						<br>
						<center>UP Los Banos</center>
						<br>
						<center><b>Progress Report Card</b></center>
						<br>
						<center>Academic Year ";

			foreach($result['students'] as $s){
				$student_name = $s->Student_name;
				$count+=1;
			}
			if($count == 0){
				$this->load->view('zeroResult');
			}else{
				$result['students'] = $this->report_model->getAcademicYear($data1, $data2);	//For the academic year
				foreach($result['students'] as $s){
					$start_of_acad = $s->start_of_academic_year;
					$end_of_acad = $s->end_of_academic_year;
				}
				$result['students'] = $this->report_model->getYearAndSection($data1, $data2);	//for the year and section
				foreach($result['students'] as $s){
					$s_year = (string)$s->student_year;
					$s_section = (string)$s->section;
				}
				
				$result['students'] = $this->report_model->getNationality($data1);	//for the nationality
				foreach($result['students'] as $s){
					$s_nat = $s->nationality;
				}

				$result['students'] = $this->report_model->getGender($data1);	//for the gender
				foreach($result['students'] as $s){
					$s_gender = $s->Student_sex;
				}

				$result['students'] = $this->report_model->getAge($data1);	//for the age
				foreach($result['students'] as $s){
					$s_age = floor($s->age);
				}

				$string .= $start_of_acad." - ".$end_of_acad."</center><br><br>";
				$string .= "<b>Name:</b> ".$student_name."
							<b>Year and Section:</b> ".$s_year." - ".$s_section."<br>";
				$string .= "<b>Nationality:</b> ".$s_nat." ";
				$string .= "<b>Gender:</b> ".$s_gender." ";
				$string .= "<b>Age:</b> ".$s_age."<br>";
				$string .= "<b>Curriculum College Prepository</b>
							<br>
							<br>
							<center><b>GRADES OBTAINED</b></center>
							<br>
							";
				$string .= '<table style="width:100%">
							<tr>
								<td><b>SUBJECTS</b></td>
								<td><b>1st GP</b></td>
								<td><b>2nd GP</b></td>
								<td><b>3rd GP</b></td>
								<td><b>4th GP</b></td>
								<td><b>Final Grade</b></td>
								<td><b>Unit</b></td>
								<td><b>Action</b></td>
							</tr>';
				$result['students'] = $this->report_model->getStudent_Subject($data1, $data2);	//for the subject datas
				$temp_string = ""; //for secondary storage of data
				foreach($result['students'] as $s){
					$rowcount = 0;
					$temp_string = "";
					$string .= "<tr>
								<td><b>".$s->Subject_name."</b> (".$s->description.") </td>";
					$temp_string .= "<td>".$s->Final_grade."</td>
									<td>".$s->Subject_unit."</td>
									
									<td>".$s->Subject_action."</td>";

					$subject_id = (int)$s->Subject_id;
					$result2['students'] = $this->report_model->getSubject_Grade($data1, $data2, $subject_id);	//for the indiviual grades per period
					$rowcount = 4 - count($result2['students']);
					foreach($result2['students'] as $s1){
						$string .= "<td>".$s1->grade."</td>";
					}
					for($i = 0; $i < $rowcount; $i++){
						$string .= "<td></td>";
					}
					$string .= $temp_string."</tr>";
				}

				$string .= "</table><br>";

				$string .= '<table style="width:100%">
							<tr>
								<td><center><b>ATTENDANCE</b></center></td>
								<td><center><b>Total</b></center></td>
							</tr>
							<tr>
								<td><b>No of School Days</b></td>';

				$school_days = 0;
				$days_present = 0;
				$days_tardy = 0;

				$result['students'] = $this->report_model->getAttendance($data1, $data2);
				foreach($result['students'] as $s){
					$school_days = $s->total_school_days;
					$days_present = $s->total_days_present;
					$days_tardy = $s->total_days_tardy;
				}

				$string .= "<td><center>".$school_days."</center></td></tr>
				<tr><td><b>No of Days Present</b></td><td><center>".$days_present."</center></td></tr>
				<tr><td>No of Times Tardy</td><td><center>".$days_tardy."</center></td></tr>
				</table>";

				include_once('dompdf/dompdf_config.inc.php');
				$dompdf = new DOMPDF();
				$dompdf->load_html($string);
				$dompdf->render();
				$dompdf->stream('reportcard.pdf');
			}
		}	
	}			
}

?>