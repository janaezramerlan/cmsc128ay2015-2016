<?php

class subject extends CI_Controller {
	

	function index()
	{
	}
	function LoadAddSubject(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('addsubject');
	}//end of LoadAddSubject function
	function LoadDeleteSubject(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('deletesubject');
	}//end of LoadAddSubject function
	function LoadAddSubjectToStudent(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('addStudentToSubject');
	}//end of LoadAddSubject function
	function LoadDeleteSubjectFromStudent(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('deleteStudentFromSubject');
	}//end of LoadAddSubject function
	function LoadEditSubject(){
			$this->load->helper(array('form', 'url'));
			$this->load->view('editSubject');
	}//end of LoadEditSubject function
	function AddSubject(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('subject_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('subject_name', 'Subject Name', 'required');
		$this->form_validation->set_rules('subject_desc', 'Subject Description', 'required');
		$this->form_validation->set_rules('subject_unit', 'Subject Unit', 'required');
		$this->form_validation->set_rules('subject_type', 'Subject Type', 'required');
		$this->form_validation->set_rules('subject_teacher', 'Subject Teacher', 'required');
		$this->form_validation->set_rules('time_start', 'Time Start', 'required');
		$this->form_validation->set_rules('time_end', 'Time End', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('addsubject');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			//GET USER INPUT
			$subject_data = array(
							'Subject_type' => $this->input->post('subject_type'),
							'Subject_unit' => $this->input->post('subject_unit'),
							'Subject_name' => $this->input->post('subject_name'),
							'Time_slot_start' => $this->input->post('time_start'),
							'Description' => $this->input->post('subject_desc'),
							'Emp_num' => $this->input->post('subject_teacher'),
							'Time_slot_end' => $this->input->post('time_end')
			);	
			//------------------CHECK IF SUBJECT EXISTS-------------------//
			$table = "subject";
			$attribute = "Subject_name";
			$this->load->model('account');
			$result2 = $this->account->exist2($table,$this->input->post('subject_name'), $attribute);
			if($result2){
				$this->load->view('formsuccess');
			}
			else{
				//CALL ADD SUBJECT FUNCTION
				$result = $this->subject_model->AddSubjectModel($subject_data);
				//IF SUCCESSFUL ADDING SUBJECT GO TO HOME
				if($result){
					$this->load->helper('date');
					$this->load->library('session');
					$this->load->model('logs_model');
					
					//--------------------------for logs---------------------------------/
					$data2 = array(
					   'date'  => standard_date('DATE_ATOM', time()),
					   'emp_num'  => $this->session->userdata('emp_num'),
					   'activity' => 'Added Subject',
					   'remarks' => $this->input->post('subject_name')
					);
					$this->logs_model->AddLogs($data2);

				
					$this->load->view('formsuccess');
				}
			}
		}
			
				
	}//end of add subject function
	
	function DeleteSubject(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('subject_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('name', 'Subject Name', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('deletesubject');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			
			$subject_name = $this->input->post('name');
			//-------------------------CHECK IF SUBJECT EXISTS-------------------//
			$table = "subject";
			$attribute = "Subject_id";
			$this->load->model('account');
			$result2 = $this->account->exist($table,$subject_name, $attribute);
			
			if($result2){
				//CALL DELETE SUBJECT FUNCTION
				$result = $this->subject_model->DeleteSubjectModel($subject_name);
				//IF SUCCESSFUL DELETING SUBJECT GO TO HOME
				if($result){
					$this->load->helper('date');
					$this->load->library('session');
					$this->load->model('logs_model');
					
					//--------------------------for logs---------------------------------/
					$data2 = array(
					   'date'  => standard_date('DATE_ATOM', time()),
					   'emp_num'  => $this->session->userdata('emp_num'),
					   'activity' => 'Deleted Subject',
					   'remarks' => $subject_name
					);
					$this->logs_model->AddLogs($data2);
				
					$this->load->view('formsuccess');
				}
			}//end of checking existence
			//-----------------DOES NOT EXIST----------------------------------------//
			else{
				$this->load->view('formsuccess'); // go back to home
			}
		}
			
				
	}//end of delete subject function

	function EditSubject(){
		//LOAD LIBRARIES AND MODEL
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('subject_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('Subject_id', 'Subject ID', 'required');
		$this->form_validation->set_rules('Subject_type', 'Subject Type', 'required');
		$this->form_validation->set_rules('Subject_unit', 'Subject Unit', 'required');
		$this->form_validation->set_rules('Subject_name', 'Subject Name', 'required');
		$this->form_validation->set_rules('Time_slot_start', 'Time slot start', 'required');
		$this->form_validation->set_rules('Description', 'Description', 'required');
		$this->form_validation->set_rules('Time_slot_end', 'Time slot end', 'required');
		$this->form_validation->set_rules('subject_teacher', 'Subject Teacher', 'required');
		
		//NOT SUCCESSFUL FILLING UP GO TO EDIT STUDENT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('editSubject');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			$data = array(
							'Subject_type' => $this->input->post('Subject_type'),
							'Subject_unit' => $this->input->post('Subject_unit'),
							'Subject_name' => $this->input->post('Subject_name'),
							'Time_slot_end' => $this->input->post('Time_slot_start'),
							'Description' => $this->input->post('Description'),
							'Emp_num' => $this->input->post('subject_teacher'),
							'Time_slot_end' => $this->input->post('Time_slot_end')
			);
			
			//-------------------------CHECK IF SUBJECT EXISTS-------------------//
			$table = "subject";
			$attribute = "Subject_id";
			$this->load->model('account');
			$result2 = $this->account->exist($table,$this->input->post('Subject_id'), $attribute);
			
			if($result2){
			
				//CALL EDIT SUBJECT FUNCTION
				$result = $this->subject_model->editSubject($data,$this->input->post('Subject_id'));
				//IF SUCCESSFUL EDITING SUBJECT  GO TO HOME
				if($result){
					$this->load->helper('date');
					$this->load->library('session');
					$this->load->model('logs_model');
					
					//--------------------------for logs---------------------------------/
					$data2 = array(
					   'date'  => standard_date('DATE_ATOM', time()),
					   'emp_num'  => $this->session->userdata('emp_num'),
					   'activity' => 'Edited Subject',
					   'remarks' => $this->input->post('Subject_id')
					);
					$this->logs_model->AddLogs($data2);
					$this->load->view('formsuccess');
				}
			}//end of existence
			//---------------------DOES NOT EXIST--------------------------//
			else{
				$this->load->view('formsuccess');
			}
		}
			
				
	}//end of edit subject  function


	
	function AddSubjecttoStudent(){
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('subject_student_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('subject_id', 'Subject ID', 'required');
		$this->form_validation->set_rules('student_id', 'Student ID', 'required');
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('addStudentToSubject');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			//GET USER INPUT
			$subject_data = array(
							'student_id' => $this->input->post('student_id'),
							'subject_id' => $this->input->post('subject_id'),
							'Final_grade' =>0,
							'Subject_action'=>'F'
			);	
			//-------------------------CHECK IF SUBJECT && STUDENT EXISTS-------------------//
			$table = "student";
			$attribute = "student_id";
			$this->load->model('account');
			$result2 = $this->account->exist($table,$subject_data['student_id'], $attribute);
			$table = "subject";
			$attribute = "subject_id";
			$result3 = $this->account->exist($table,$subject_data['subject_id'], $attribute);
			
			if($result2&&$result3){
				//CALL ADD SUBJECT TO STUDENT FUNCTION
				$result = $this->subject_student_model->AddSubjectToStudent($subject_data);
				//IF SUCCESSFUL ADDING SUBJECT GO TO HOME
					if($result){
						$this->load->helper('date');
						$this->load->library('session');
						$this->load->model('logs_model');
						
						//--------------------------for logs---------------------------------/
						$data2 = array(
						   'date'  => standard_date('DATE_ATOM', time()),
						   'emp_num'  => $this->session->userdata('emp_num'),
						   'activity' => 'Added Subject To Student',
						   'remarks' => $this->input->post('subject_id')
						);
						$this->logs_model->AddLogs($data2);

						$this->load->view('formsuccess');
					}
			}//end of exist
			else{
				$this->load->view('formsuccess'); //go back to home
			}
		}
			
	}//end of function
	
	function DeleteSubjectFromStudent(){
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$this->load->model('subject_student_model');
		
		//FORM VALIDATION
		$this->form_validation->set_rules('subject_id', 'Subject ID', 'required');
		$this->form_validation->set_rules('student_id', 'Student ID', 'required');
		//NOT SUCCESSFUL FILLING UP GO TO ADDSUBJECT PAGE
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('addStudentToSubject');
		}
		//SUCCESSFUL FILLING UP
		else
		{
			//GET USER INPUT
			$student_id = $this->input->post('student_id');
			$subject_id = $this->input->post('subject_id');
			//-------------------------CHECK IF SUBJECT && STUDENT EXISTS-------------------//
			$table = "student";
			$attribute = "student_id";
			$this->load->model('account');
			$result2 = $this->account->exist($table,$student_id, $attribute);
			$table = "subject";
			$attribute = "subject_id";
			$result3 = $this->account->exist($table,$subject_id, $attribute);
			
			if($result2&&$result3){
			
				//CALL DELETE SUBJECT FUNCTION
				$result = $this->subject_student_model->DeleteSubjectFromStudent($student_id,$subject_id);
				//IF SUCCESSFUL DELETING SUBJECT GO TO HOME
				if($result){
					$this->load->helper('date');
					$this->load->library('session');
					$this->load->model('logs_model');
					
					//--------------------------for logs---------------------------------/
					$data2 = array(
					   'date'  => standard_date('DATE_ATOM', time()),
					   'emp_num'  => $this->session->userdata('emp_num'),
					   'activity' => 'Deleted Subject from Student',
					   'remarks' => $this->input->post('student_id')
					);
					$this->logs_model->AddLogs($data2);
					$this->load->view('formsuccess');
				}
			}
			else{
				$this->load->view('formsuccess');
			}
		}
			
	}//end of function

	
}	
	


?>