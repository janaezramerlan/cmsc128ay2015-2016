<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class student_model extends CI_Model {
	
	//GET DATA
	function getData($student_id){
		$this->load->database();
		$query = "SELECT * FROM student WHERE student_id = '".$student_id."'";
		return $this->db->query($query)->result();
	}
	
	 //GET ALL STUDENT DATA OF A CERTAIN STUDENT
	 function getStudentData($studname){
        $this->load->database();
		$query = "SELECT Student_id, Student_name, Student_sex, status, address, nationality, curriculum, birthdate FROM students WHERE Student_name LIKE '".$studname."'";
        $queryresults =  $this->db->query($query)->result();
        return $queryresults; 
     }
	 //GET STUDENT ID OF A STUDENT GIVEN A HIS/HER NAME
	 function getStudentID($studname){
		$this->load->database();
		$query = "SELECT Student_id FROM students WHERE Student_name LIKE '".$studname."'";
        $queryresults =  $this->db->query($query)->result();
        return $queryresults; 
     }
	 //ADD STUDENT
     function addStudent($student_data){
     	$this->load->database();
     	$this->db->insert('student', $student_data);
		return TRUE;
     }
	
	//DELETE STUDENT
     function deleteStudent($name){
     	$this->load->database();
        $query = "DELETE FROM student WHERE student_id = '".$name."'"; 
        $this->db->query($query);
        return TRUE;
     }
	 //EDIT STUDENT
	 function editStudent($data, $Student_id){
        $this->load->database();
		$this->db->where('Student_id', $Student_id);
        $this->db->update('student', $data);
        return TRUE;
    }

}
