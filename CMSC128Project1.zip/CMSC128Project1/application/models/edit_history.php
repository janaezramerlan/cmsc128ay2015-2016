<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class edit_history extends CI_Model {
	function AddData($data){
			$this->load->database();
			$this->db->insert('edit_history', $data);
	}//end of AddData
	function ViewData($emp_num){
		$this->load->database();
		$query = "SELECT*FROM edit_history WHERE emp_num ='".$emp_num."'";
		return $this->db->query($query)->result();
	}//end of viewData
	
}