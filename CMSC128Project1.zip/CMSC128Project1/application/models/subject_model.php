<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class subject_model extends CI_Model {
	public function __construct()
    {
        parent::__construct();
        //$this->load->helper('url');     
    }   

	//Get Subject ID
	 function getSubjectID($subname){
		$this->load->database();
		$query = "SELECT Subject_id FROM subject WHERE Subject_name LIKE '".$subname."'";
        $queryresults =  $this->db->query($query)->result();
        return $queryresults; 
     }

	//ADD SUBJECT BY ADMIN TO DATABASE
	function AddSubjectModel($subject_data){//FROM POST
		$this->load->database();
		$this->db->insert('subject', $subject_data);
		return TRUE;
	}
	   
	//DELETE SUBJECT BY ADMIN FROM DATABASE
	function DeleteSubjectModel($id){
		$this->load->database();
		$query = "DELETE FROM subject WHERE Subject_id = '".$id."'"; 
		$this->db->query($query);
		return TRUE;
	}
	
	function editSubject($data, $Subject_id){
        $this->load->database();
		$this->db->where('Subject_id', $Subject_id);
        $this->db->update('subject', $data);
        return TRUE;
    }
	 
}
