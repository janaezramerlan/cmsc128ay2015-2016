<html>
<head>
<title>List-of-Logs</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('logs/viewLogsByDate'); ?>

<h5>Date:</h5>
<input type="text" name="date" id = "date" value="" size="50" />
<div><input type="submit" value="View by Date" /></div>


</body>
</html>
