<html>
<head>
<title>List-of-Edit-Of-Emp</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('employee/ViewHistoryOfEmp'); ?>

<h5>Employee Number:</h5>
<input type="text" name="emp_num" id = "emp_num" value="" size="50" />
<div><input type="submit" value="View Edit History" /></div>


</body>
</html>
