<html>
<head>
<title>List-of-Logs</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('logs/viewLogsByEmp'); ?>

<h5>Employee Number:</h5>
<input type="text" name="emp_num" id = "emp_num" value="" size="50" />
<div><input type="submit" value="View by Employee" /></div>


</body>
</html>
