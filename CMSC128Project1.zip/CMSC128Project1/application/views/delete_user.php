<html>
<head>
<title>Delete-User</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('form'); ?>

<h5>Enter Employee name</h5>
<input type="text" name="name" id = "name" value="" size="50" />

<div><input type="submit" value="Delete" /></div>

</body>
</html>
