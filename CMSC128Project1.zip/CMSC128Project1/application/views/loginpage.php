
<html>

<head>
<title>Log-in Page</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/loginpage.css"/>
</head>

<body>

	<?php echo validation_errors(); ?>
	<?php echo form_open('login'); ?>
	<img src="images/logo.jpg">
	<div id = "rectangle">
	
		<div id="user">Username</div>
		<input type="text" name="username" id = "username" value="" size="50" required/>
		<br><br>
		
		<div id="pass">Password</div>
		<input type="password" name="password" id="password" value="" size="50" required/>
		<br><br>
		<input type="submit" id="login" value="Login"/>
		
	</div>
	<pre><div id="copyright"> Copyright (c) 2014 - All Rights Reserved | University of the Philippines System<br>
	   Website, Diliman Quezon City, Philippines. VoIP (+632) 981-8500.</div>
</body>
</html>
