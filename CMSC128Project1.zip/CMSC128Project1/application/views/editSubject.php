<html>
<head>
<title>EDIT-Subject</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('subject/EditSubject'); ?>

	<h5>Subject ID</h5>
	<input type="text" name="Subject_id" id = "Subject_id" value="" size="50" />

	<h5>Subject Name</h5>
	<input type="text" name="Subject_name" id = "Subject_name" value="" size="50" />

	<h5>Subject Description</h5>
	<input type="text" name="Description" id = "Description" value="" size="50" />
	
	<h5>Subject Type</h5>
	<input type="text" name="Subject_type" id = "Subject_type" value="" size="50" />

	<h5>Subject Unit</h5>
	<input type="text" name="Subject_unit" id = "Subject_unit" value="" size="50" />

	<h5>Subject Teacher(Employee Num)</h5>
	<input type="text" name="subject_teacher" id="subject_teacher" value="" size="50" />

	<h5>Time Slot Start</h5>
	<input type="text" name="Time_slot_start" id = "Time_slot_start" value="" size="50" />

	

	<h5>Time Slot End</h5>
	<input type="text" name="Time_slot_end" id = "Time_slot_end" value="" size="50" />

	<div><input type="submit" value="SAVE" /></div>
	</form>
</body>
</html>
