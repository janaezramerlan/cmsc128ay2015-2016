<html>
<head>
<title>List-of-Logs-By-Date</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('logs/LoadLogsByDate'); ?>

<?php foreach($result as $row): 
//query per student
	$content = $row->logs_id;
	$content .= "   ";
	$content .= $row->date;
	$content .= "   ";
	$content .= $row->emp_num;
	$content .= "   ";
	$content .= $row->activity;
	$content .= "   ";
	$content .= $row->remarks;
	$content .= "   ";
	$content .= "<br>";
	echo $content;
endforeach; ?>
</body>
</html>
,