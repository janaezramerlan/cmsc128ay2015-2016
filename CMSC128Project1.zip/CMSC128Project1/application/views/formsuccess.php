<html>
<head>
<title>HOME</title>
</head>
<body>

<h3>Your have successfully logged-in!</h3>

<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("login/logout");?>'">Log Out</button>
<br>
<b>SUBJECT</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subject/LoadAddSubject");?>'">ADD SUBJECT</button>

<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subject/LoadEditSubject");?>'">EDIT SUBJECT</button>


<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subject/LoadDeleteSubject");?>'">DELETE SUBJECT</button>

<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subjectgrade/LoadAddSubjectGrade");?>'">ADD SUBJECT GRADE</button>

<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subjectgrade/LoadDeleteSubjectGrade");?>'">DELETE SUBJECT GRADE</button>


<br>
<br>
<b>STUDENT</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("student/LoadAddStudent");?>'">ADD STUDENT</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("student/LoadEditStudent");?>'">EDIT STUDENT</button>

<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("student/LoadDeleteStudent");?>'">DELETE STUDENT</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("batch/LoadAddStudentToBatch");?>'">ADD STUDENT TO BATCH</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("batch/LoadDeleteStudentFromBatch");?>'">DELETE STUDENT FROM BATCH</button>

<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subject/LoadAddSubjectToStudent");?>'">ADD STUDENT TO SUBJECT</button>

<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("subject/LoadDeleteSubjectFromStudent");?>'">DELETE STUDENT FROM SUBJECT</button>

<br>
<br>
<b>ATTENDANCE</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("attendance/LoadAttendance");?>'">ADD attendance</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("attendance/LoadDeleteAttendance");?>'">DELETE attendance</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("attendance/LoadEditAttendance");?>'">EDIT attendance</button>
<br>
<br>
<b>USER</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("employee/LoadAddEmployee");?>'">ADD USER</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("employee/LoadEditEmployee");?>'">EDIT USER</button>
<br>
<br>
<b>BATCH</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("batch/LoadAddBatch");?>'">ADD BATCH</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("batch/LoadDeleteBatch");?>'">DELETE BATCH</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("batch/LoadEditBatch");?>'">EDIT BATCH</button>

<br>
<br>
<b>REPORTS</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("listofadvisees/LoadListOfAdvisees");?>'">List of Advisees</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("report/loadListSection");?>'">List of Students in a Section with Grade</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("report/loadListYear");?>'">List of Students in a Year with Grade</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("report/LoadReport");?>'">Generate Report Card</button>
<br>
<br>
<b>LOGS</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("logs/LoadLogsByDate");?>'">View Logs(by Date)</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("logs/LoadLogsByEmp");?>'">View Logs(by Employee)</button>
<br>
<br>
<b>EDIT HISTORY</b>
<br>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("employee/ViewHistory");?>'">View Edit History</button>
<button type="button" class="btn btn-success" onclick="window.location='<?php echo site_url("employee/LoadViewHistoryOfEmp");?>'">View Edit History Of an Employee</button>

</body>
</html>