<html>
<head>
<title>Delete Subject Grade</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('subjectgrade/DeleteSubjectGrade'); ?>

<h5>Student ID:</h5>
<input type="text" name="stud_id" id = "stud_id" value="" size="50" />

<h5>Subject ID:</h5>
<input type="text" name="subject_id" id = "subject_id" value="" size="50" />

<h5>Grading Period:</h5>
<input type="text" name="grading_period" id = "grading_period" value="" size="50" />

<div><input type="submit" value="Delete Subject Grade" /></div>

</body>
</html>