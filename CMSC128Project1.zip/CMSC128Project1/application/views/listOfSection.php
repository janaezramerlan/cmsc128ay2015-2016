<html>
<head>
<title>LIST-SECTION-WITH-GRADE</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('report/GenerateListSection'); ?>


	<h5>SECTION</h5>
	<input type="text" name="section" id = "section" value="" size="50" />

	<h5> SUBJECT ID</h5>
	<input type="text" name="subject_id" id = "subject_id" value="" size="50" />

	<h5>GRADING PERIOD</h5>
	<input type="text" name="grade_period" id = "grade_period" value="" size="50" />



	<div><input type="submit" value="GENERATE" /></div>
	</div>
	
	</form>
</body>
</html>
