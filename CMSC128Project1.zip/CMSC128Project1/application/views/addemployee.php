<html>
<head>
<title>ADD EMPLOYEE</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('employee/AddEmployee'); ?>

<h5>Employee Number</h5>
<input type="text" name="employee_num" id = "employee_num" value="" size="50" />

<h5>Employee Name</h5>
<input type="text" name="employee_name" id="employee_name" value="" size="50" />

<h5>Employee Designation</h5>
<input type="text" name="employee_designation" id="employee_designation" value="" size="50" />

<div><input type="submit" value="ADD EMPLOYEE" /></div>
</form>

</body>
</html>
