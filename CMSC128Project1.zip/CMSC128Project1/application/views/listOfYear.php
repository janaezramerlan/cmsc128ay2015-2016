<html>
<head>
<title>LIST-YEAR-WITH-GRADE</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('report/GenerateListYear'); ?>


	<h5>YEAR</h5>
	<input type="text" name="year" id = "year" value="" size="50" />

	<h5> SUBJECT ID</h5>
	<input type="text" name="subject_id" id = "subject_id" value="" size="50" />

	<h5>GRADING PERIOD</h5>
	<input type="text" name="grade_period" id = "grade_period" value="" size="50" />



	<div><input type="submit" value="GENERATE" /></div>
	</div>
	
	</form>
</body>
</html>
