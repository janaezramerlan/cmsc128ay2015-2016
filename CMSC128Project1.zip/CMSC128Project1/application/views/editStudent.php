<html>
<head>
<title>EDIT-Student</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('student/EditStudent'); ?>


	<h5>Student ID</h5>
	<input type="text" name="Student_id" id = "Student_id" value="" size="50" />

	<h5>Student Name</h5>
	<input type="text" name="Student_name" id = "Student_name" value="" size="50" />

	<h5>Sex</h5>
	<input type="text" name="Student_sex" id = "Student_sex" value="" size="50" />

	<h5>Status</h5>
	<input type="text" name="status" id = "status" value="" size="50" />

	<h5>Address</h5>
	<input type="text" name="address" id = "address" value="" size="50" />

	<h5>Nationality</h5>
	<input type="text" name="nationality" id = "nationality" value="" size="50" />

	<h5>Curriculum</h5>
	<input type="text" name="curriculum" id = "curriculum" value="" size="50" />

	<h5>Birthdate</h5>
	<input type="text" name="birthdate" id = "birthdate" value="" size="50" />

	<div><input type="submit" value="SAVE" /></div>
	</form>
</body>
</html>
