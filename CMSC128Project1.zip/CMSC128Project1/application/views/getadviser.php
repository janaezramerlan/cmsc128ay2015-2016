<html>
<head>
<title>List-of-Advisees</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('listofadvisees/viewAdvisees'); ?>

<h5>Adviser Name:</h5>
<input type="text" name="adviser" id = "adviser" value="" size="50" />
<h5>Academic Year:</h5>
<input type="text" name="year" id = "year" value="" size="50" />


<div><input type="submit" value="List of Advisees" /></div>

</body>
</html>
