<html>
<head>
<title>Delete-Student</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('student/DeleteStudent'); ?>

<h5>Student ID</h5>
<input type="text" name="name" id = "name" value="" size="50" />

<div><input type="submit" value="Delete" /></div>

</body>
</html>
