<html>
<head>
<title>Edit Batch</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('batch/EditBatch'); ?>

<h5>Batch ID</h5>
<input type="text" name="batch_id" id="batch_id" value="" size="50" />

<h5>Student Year</h5>
<input type="text" name="student_year" id="student_year" value="" size="50" />

<h5>Class Section</h5>
<input type="text" name="section" id="section" value="" size="50" />

<h5>Class Adviser</h5>
<input type="text" name="adviser" id="adviser" value="" size="50" />

<h5>Start Of Academic Year</h5>
<input type="text" name="start_of_academic_year" id="start_of_academic_year" value="" size="50" />

<h5>End Of Academic Year</h5>
<input type="text" name="end_of_academic_year" id="end_of_academic_year" value="" size="50" />

<div><input type="submit" value="SAVE CHANGES" /></div>
</form>

</body>
</html>
