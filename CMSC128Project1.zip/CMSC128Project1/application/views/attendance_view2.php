<html>
<head>
<title>Add-Student</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('attendance/deleteAttendance'); ?>

<h5>Student ID:</h5>
<input type="text" name="stud_id" id = "stud_id" value="" size="50" />

<h5>Batch ID:</h5>
<input type="text" name="batch_id" id = "batch_id" value="" size="50" />


<h5>Grading Period:</h5>
<input type="text" name="period" id = "period" value="" size="50" />

<div><input type="submit" value="Delete Attendance" /></div>

</body>
</html>
