<html>
<head>
<title>List-of-Advisees</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('listofadvisees/viewAdvisees'); ?>

<?php foreach($query as $row): 
//query per student
?>
<tr>
	<td><?php echo $row->Student_name; echo "<br/>"?></td>
</tr>
<?php endforeach; ?>
</body>
</html>
