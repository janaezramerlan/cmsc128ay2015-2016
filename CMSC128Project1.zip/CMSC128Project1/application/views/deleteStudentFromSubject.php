<html>
<head>
<title>Delete student from Batch</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('subject/DeleteSubjectFromStudent'); ?>

<h5>Subject ID</h5>
<input type="text" name="subject_id" id = "subject_id" value="" size="50" />

<h5>Student ID</h5>
<input type="text" name="student_id" id = "student_id" value="" size="50" />


<div><input type="submit" value="Delete Student From Batch" /></div>

</body>
</html>
