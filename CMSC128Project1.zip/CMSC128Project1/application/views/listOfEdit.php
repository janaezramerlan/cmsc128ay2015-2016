<html>
<head>
<title>List-of-EDIT</title>
</head>
<body>

<?php foreach($result as $row): 
//query per student
	$content = $row->emp_num;
	$content .= "   ";
	$content .= $row->date;
	$content .= "   ";
	$content .= $row->page;
	$content .= "   ";
	$content .= $row->remarks;
	$content .= "   ";
	$content .= "<br>";
	echo $content;
endforeach; ?>
</body>
</html>
