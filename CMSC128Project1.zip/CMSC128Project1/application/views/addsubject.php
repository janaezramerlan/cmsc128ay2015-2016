<html>
<head>
<title>ADD SUBJECT</title>
</head>
<body>

<?php echo validation_errors(); ?>

<?php echo form_open('subject/AddSubject'); ?>

<h5>Subject Name</h5>
<input type="text" name="subject_name" id = "subject_name" value="" size="50" />

<h5>Subject Description</h5>
<input type="text" name="subject_desc" id="subject_desc" value="" size="50" />

<h5>Subject Unit</h5>
<input type="text" name="subject_unit" id="subject_unit" value="" size="50" />

<h5>Subject Type</h5>
<input type="text" name="subject_type" id="subject_type" value="" size="50" />

<h5>Subject Teacher(Employee Num)</h5>
<input type="text" name="subject_teacher" id="subject_teacher" value="" size="50" />


<h5>Time Start</h5>
<input type="text" name="time_start" id="time_start" value="" size="50" />

<h5>Time End</h5>
<input type="text" name="time_end" id="time_end" value="" size="50" />

<div><input type="submit" value="ADD SUBJECT" /></div>
</form>

</body>
</html>
